import cv2, numpy as np, matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline
from scipy.spatial import cKDTree

ARCHIVO = "Monolito_Fraile.png"
PERDIDOS = [9, 10, 11]            # P10, P11, P12 (índices desde 0): zona "dañada" simulada
DORADO, CIAN, MAGENTA, ROJO = "#f2b84b", "#19d3d3", "#ff4fd8", "#ff4d4d"

# 1) Imagen sobre fondo oscuro
img = cv2.imread(ARCHIVO, cv2.IMREAD_UNCHANGED)
if img.ndim == 3 and img.shape[2] == 4 and img[..., 3].min() < 255:
    mask = img[..., 3] > 20; bgr = img[..., :3]
else:
    bgr = img[..., :3]; mask = ~np.all(bgr > 235, axis=2)
h, w = mask.shape
vista = cv2.cvtColor(np.where(mask[..., None], bgr, np.full((h, w, 3), 30, np.uint8)), cv2.COLOR_BGR2RGB)

# 2) Puntos de control (coordenadas de imagen: y hacia abajo)
d = np.loadtxt("puntos.csv", delimiter=",", skiprows=1)
P = np.column_stack([d[:, 0], h - d[:, 1]])

def spline(P):
    dist = np.linalg.norm(np.diff(P, axis=0), axis=1)
    t = np.concatenate([[0], np.cumsum(np.sqrt(dist))])
    return CubicSpline(t, P, bc_type="natural"), t

def curva(P, n=3000):
    S, t = spline(P)
    return S(np.linspace(0, t[-1], n))

S, t = spline(P)
ref = curva(P)                                           # contorno original (15 puntos)

# 3) PLAN A: puente directo (se quitan los puntos perdidos)
PA = np.delete(P, PERDIDOS, axis=0)
cA = curva(PA)

# 4) PLAN B: simetría respecto a un eje vertical
#    eje = centro del ancho del contorno CONSERVADO (sin usar la zona dañada)
xc = (cA[:, 0].min() + cA[:, 0].max()) / 2
mitad_der = S(np.linspace(0, t[7], 2000))                # lado derecho: de P1 a la coronilla (P8)
PB = P.copy()
for p in PERDIDOS:
    j = np.argmin(abs(mitad_der[:, 1] - P[p, 1]))        # punto del lado derecho a la misma altura
    PB[p] = (2 * xc - mitad_der[j, 0], P[p, 1])          # su reflejo
cB = curva(PB)

# 5) Error dentro de la zona reconstruida (entre P9 y P13)
zona = S(np.linspace(t[PERDIDOS[0] - 1], t[PERDIDOS[-1] + 1], 600))
def error(c):
    dd, _ = cKDTree(c).query(zona)
    return dd.mean(), dd.max()
eA, eB = error(cA), error(cB)
print(f"Zona reconstruida: P{PERDIDOS[0]+1} a P{PERDIDOS[-1]+1}  |  eje de simetría x = {xc:.1f}")
print(f"Plan A (puente directo): error medio = {eA[0]:.1f} px | máximo = {eA[1]:.1f} px")
print(f"Plan B (simetría):       error medio = {eB[0]:.1f} px | máximo = {eB[1]:.1f} px")

# 6) Figura comparativa
m = 40
x0, x1 = P[:, 0].min() - m, P[:, 0].max() + m
y0, y1 = P[:, 1].min() - m, P[:, 1].max() + m
fig, axs = plt.subplots(1, 3, figsize=(18, 7), facecolor="#14161c")
datos = [("Original: 15 puntos", ref, CIAN, P, False),
         (f"Plan A: puente directo (err. medio {eA[0]:.1f} px)", cA, CIAN, PA, False),
         (f"Plan B: simetría (err. medio {eB[0]:.1f} px)", cB, MAGENTA, PB, True)]
for ax, (tit, c, col, pts, refl) in zip(axs, datos):
    ax.imshow(vista)
    ax.plot(ref[:, 0], ref[:, 1], color="white", lw=1.2, ls="--", alpha=0.7, label="contorno original")
    ax.plot(c[:, 0], c[:, 1], color=col, lw=2.5, label="spline")
    ax.plot(pts[:, 0], pts[:, 1], "o", color=DORADO, ms=6)
    if refl:
        ax.plot(PB[PERDIDOS, 0], PB[PERDIDOS, 1], "s", color=MAGENTA, ms=8, label="puntos reflejados")
    if tit != "Original: 15 puntos":
        ax.plot(P[PERDIDOS, 0], P[PERDIDOS, 1], "x", color=ROJO, ms=11, mew=3, label="puntos perdidos")
    ax.set_xlim(x0, x1); ax.set_ylim(y1, y0)
    ax.set_title(tit, color="white", fontsize=12); ax.axis("off")
    ax.legend(loc="lower right", fontsize=8, facecolor="#14161c", labelcolor="white")
plt.tight_layout()
plt.savefig("comparacion_reconstruccion.png", dpi=200, facecolor=fig.get_facecolor())
plt.show()
import cv2, numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, ConnectionPatch
from scipy.interpolate import CubicSpline

ARCHIVO = "Monolito_Fraile.png"
DORADO = "#f2b84b"

# 1) Imagen sobre fondo oscuro
img = cv2.imread(ARCHIVO, cv2.IMREAD_UNCHANGED)
if img.ndim == 3 and img.shape[2] == 4 and img[..., 3].min() < 255:
    mask = img[..., 3] > 20
    bgr = img[..., :3]
else:
    bgr = img[..., :3]
    mask = ~np.all(bgr > 235, axis=2)
h, w = mask.shape
fondo = np.full((h, w, 3), 30, np.uint8)
vista = cv2.cvtColor(np.where(mask[..., None], bgr, fondo), cv2.COLOR_BGR2RGB)

# 2) Puntos de control (el CSV tiene el eje y invertido) y spline
d = np.loadtxt("puntos.csv", delimiter=",", skiprows=1)
P = np.column_stack([d[:, 0], h - d[:, 1]])
dist = np.linalg.norm(np.diff(P, axis=0), axis=1)
t = np.concatenate([[0], np.cumsum(np.sqrt(dist))])
curva = CubicSpline(t, P, bc_type="natural")(np.linspace(0, t[-1], 2000))

# 3) Caja de la zona elegida
m = 40
x0 = max(P[:, 0].min() - m, 0);  x1 = min(P[:, 0].max() + m, w)
y0 = max(P[:, 1].min() - m, 0);  y1 = min(P[:, 1].max() + m, h)
x0, x1, y0, y1 = int(x0), int(x1), int(y0), int(y1)

# 4) Monolito completo con todo atenuado excepto la zona
tenue = (vista * 0.35).astype(np.uint8)
tenue[y0:y1, x0:x1] = vista[y0:y1, x0:x1]

fig = plt.figure(figsize=(13, 8), facecolor="#14161c")
ax1 = fig.add_axes([0.03, 0.04, 0.30, 0.86])
ax2 = fig.add_axes([0.42, 0.10, 0.55, 0.78])

ax1.imshow(tenue)
ax1.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False,
                        ec=DORADO, lw=2.5, ls="--"))
ax1.set_title("Monolito Fraile (Tiwanaku)\nZona a reconstruir", color="white", fontsize=12)
ax1.axis("off")

ax2.imshow(vista)
ax2.plot(curva[:, 0], curva[:, 1], color="#19d3d3", lw=2.5)
ax2.plot(P[:, 0], P[:, 1], "o", color=DORADO, ms=7)
for i, (x, y) in enumerate(P, 1):
    ax2.text(x + 8, y - 8, f"P{i}", color="white", fontsize=9)
ax2.set_xlim(x0, x1); ax2.set_ylim(y1, y0)
ax2.set_title("Puntos de control y spline cúbico paramétrico", color="white", fontsize=12)
for s in ax2.spines.values():
    s.set_edgecolor(DORADO); s.set_linewidth(2.5)
ax2.set_xticks([]); ax2.set_yticks([])

# 5) Líneas que unen la caja con el zoom
for (xa, ya), (xb, yb) in [((x1, y0), (0, 1)), ((x1, y1), (0, 0))]:
    fig.add_artist(ConnectionPatch(xyA=(xa, ya), coordsA=ax1.transData,
                                   xyB=(xb, yb), coordsB=ax2.transAxes,
                                   color=DORADO, lw=1.5, ls=":"))

plt.savefig("escena_contexto.png", dpi=200, facecolor=fig.get_facecolor())
plt.show()
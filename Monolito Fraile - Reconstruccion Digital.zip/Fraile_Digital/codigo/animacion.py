import warnings; warnings.filterwarnings("ignore")
import sys, cv2, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FFMpegWriter
from scipy.interpolate import CubicSpline
from scipy.spatial import cKDTree
import imageio_ffmpeg
matplotlib.rcParams["animation.ffmpeg_path"] = imageio_ffmpeg.get_ffmpeg_exe()

ARCHIVO = "Monolito_Fraile.png"
PERDIDOS = [9, 10, 11]            # P10, P11, P12
FPS, DPI = 20, 200 / 3           # 1280 x 720 a 20 cuadros por segundo (el video de la app)
BG, DOR, CIAN, MAG, ROJO = "#14161c", "#f2b84b", "#19d3d3", "#ff4fd8", "#ff4d4d"
AZUL = "#3d8bff"

# ---------- 1) Datos ----------
img = cv2.imread(ARCHIVO, cv2.IMREAD_UNCHANGED)
if img.ndim == 3 and img.shape[2] == 4 and img[..., 3].min() < 255:
    mask = img[..., 3] > 20; bgr = img[..., :3]
else:
    bgr = img[..., :3]; mask = ~np.all(bgr > 235, axis=2)
h, w = mask.shape
vista = cv2.cvtColor(np.where(mask[..., None], bgr, np.full((h, w, 3), 30, np.uint8)), cv2.COLOR_BGR2RGB)

d = np.loadtxt("puntos.csv", delimiter=",", skiprows=1)
P = np.column_stack([d[:, 0], h - d[:, 1]])              # coordenadas de imagen (y hacia abajo)
n = len(P) - 1

def spline(P):
    dist = np.linalg.norm(np.diff(P, axis=0), axis=1)
    t = np.concatenate([[0], np.cumsum(np.sqrt(dist))])
    return CubicSpline(t, P, bc_type="natural"), t
def curva(P, m=3000):
    S, t = spline(P); return S(np.linspace(0, t[-1], m))

S, t = spline(P)
ref = curva(P)
seg = [S(np.linspace(t[i], t[i + 1], 150)) for i in range(n)]
PA = np.delete(P, PERDIDOS, axis=0); cA = curva(PA)
xc = (cA[:, 0].min() + cA[:, 0].max()) / 2
der = S(np.linspace(0, t[7], 2000))
PB = P.copy()
for p in PERDIDOS:
    j = np.argmin(abs(der[:, 1] - P[p, 1])); PB[p] = (2 * xc - der[j, 0], P[p, 1])
cB = curva(PB)
zona = S(np.linspace(t[PERDIDOS[0] - 1], t[PERDIDOS[-1] + 1], 600))
def error(c):
    dd, _ = cKDTree(c).query(zona); return dd.mean(), dd.max()
eA, eB = error(cA), error(cB)
gan = "A" if eA[0] <= eB[0] else "B"

# continuidad medida con los coeficientes de cada tramo
c = S.c; hh = np.diff(t); e0 = e1 = e2 = 0.0
for i in range(1, n):
    k = i - 1; H = hh[k]
    v = c[0, k] * H**3 + c[1, k] * H**2 + c[2, k] * H + c[3, k]
    d1 = 3 * c[0, k] * H**2 + 2 * c[1, k] * H + c[2, k]
    d2 = 6 * c[0, k] * H + 2 * c[1, k]
    e0 = max(e0, np.linalg.norm(v - c[3, i])); e1 = max(e1, np.linalg.norm(d1 - c[2, i]))
    e2 = max(e2, np.linalg.norm(d2 - 2 * c[1, i]))

# ---------- 1b) Validación: daño simulado y reconstrucción del material ----------
cR = cA if gan == "A" else cB
eR = eA if gan == "A" else eB
ys_, xs_ = np.mgrid[0:h, 0:w]
Lc = S(np.linspace(t[PERDIDOS[0] - 1], t[PERDIDOS[-1] + 1], 300))
s_ = np.linspace(0, 1, 300)
prof = np.sin(np.pi * s_) ** 0.7 * (1 + 0.18 * np.sin(6.0 * s_ + 0.8))
D = 45                                                  # profundidad del "mordisco" en px
inner = Lc + np.column_stack([D * prof, np.zeros_like(s_)])
outer = Lc - np.column_stack([12 * np.ones_like(s_), np.zeros_like(s_)])
tmp = np.zeros((h, w), np.uint8)
cv2.fillPoly(tmp, [np.vstack([outer, inner[::-1]]).astype(np.int32)], 1)
bite = (tmp > 0) & mask
dam_mask = mask & ~bite
ORIG = vista
DAM = vista.copy(); DAM[bite] = (30, 30, 30)

Y_CHORD = max(P[0, 1], P[-1, 1])
tmp[:] = 0
cv2.fillPoly(tmp, [np.vstack([cR, [cR[-1, 0], Y_CHORD], [cR[0, 0], Y_CHORD]]).astype(np.int32)], 1)
fy0, fy1 = int(Lc[:, 1].min()) - 15, int(Lc[:, 1].max()) + 15
fill = (tmp > 0) & ~dam_mask & (ys_ >= fy0) & (ys_ <= fy1) & (xs_ < xc)
fill = cv2.morphologyEx(fill.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) > 0

REC = DAM.copy()
for y in np.where(fill.any(axis=1))[0]:
    xf = np.where(fill[y])[0]
    xin = np.where(dam_mask[y, :int(xc)])[0]
    if len(xin) == 0: continue
    REC[y, xf] = DAM[y, np.clip(2 * xin.min() - xf, 0, w - 1)]
tinte = np.array(matplotlib.colors.to_rgb(CIAN)) * 255
REC[fill] = (0.80 * REC[fill] + 0.20 * tinte).astype(np.uint8)

# ---------- 1c) Restauración hipotética "como nueva" (zona azul con spline + pulido) ----------
XA = 535                 # x del eje de la cara (solo se usa para cerrar el poligono azul)
Y_ARC = 440              # por debajo de esta fila se conserva el cuerpo original
N_REST, PULIDO = 15, 0.25 # puntos de control (8 a 15) e intensidad del pulido (0 a 1)
# Zona a reconstruir (AZUL): borde exterior de la parte superior izquierda de la cabeza.
# Se define con 8 puntos de control (x, y en px de la imagen) y un spline cubico natural.
PUNTOS_AZUL = np.array([[470, 62], [440, 68], [388, 80], [361, 107],
                        [343, 153], [340, 214], [343, 259], [347, 285]], float)
_da = np.sqrt(np.linalg.norm(np.diff(PUNTOS_AZUL, axis=0), axis=1))
T_AZ = np.concatenate([[0], np.cumsum(_da)])
SPL_AZUL = CubicSpline(T_AZ, PUNTOS_AZUL, bc_type="natural")
curva_az = SPL_AZUL(np.linspace(0, T_AZ[-1], 600))
_poli = np.vstack([curva_az, [XA, curva_az[-1, 1]], [XA, curva_az[0, 1]]]).astype(np.int32)
azul = np.zeros((h, w), np.uint8); cv2.fillPoly(azul, [_poli], 1); azul = azul > 0
mask_u = mask | azul                                  # silueta restaurada (sin simetria)
falta = azul & ~mask                                  # material que "faltaba" = zona azul

from scipy.ndimage import gaussian_filter1d
_cn, _ = cv2.findContours(mask_u.astype(np.uint8) * 255, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
CC = max(_cn, key=cv2.contourArea)[:, 0, :].astype(float)
CC = np.roll(CC, -int(np.argmin(CC[:, 1])), axis=0); MM = len(CC)
ff = 0
while CC[ff, 1] < Y_ARC: ff += 1
bb = MM - 1
while CC[bb, 1] < Y_ARC: bb -= 1
arco = np.vstack([CC[bb + 1:], CC[:ff]])
arco = np.column_stack([gaussian_filter1d(arco[:, 0], 3, mode="nearest"), gaussian_filter1d(arco[:, 1], 3, mode="nearest")])
LL = len(arco)
def _construir(ix):
    Pp = arco[ix]; dd_ = np.linalg.norm(np.diff(Pp, axis=0), axis=1)
    tt = np.concatenate([[0], np.cumsum(np.sqrt(dd_))])
    return Pp, CubicSpline(tt, Pp, bc_type="natural")(np.linspace(0, tt[-1], 3000))
def _errores(ix):
    Pp, cv_ = _construir(ix); e1_, _ = cKDTree(cv_).query(arco); e2_, j2_ = cKDTree(arco).query(cv_)
    return Pp, cv_, e1_, e2_, j2_
def _costo(ix):
    _, _, e1_, e2_, _ = _errores(ix); return max(e1_.max(), e2_.max()) + e1_.mean() + e2_.mean()
idxR = [0, LL // 3, 2 * LL // 3, LL - 1]
while len(idxR) < N_REST:                              # selección adaptativa de puntos
    so = sorted(idxR); _, _, e1_, e2_, j2_ = _errores(so); e1_[so] = 0
    i1 = int(np.argmax(e1_)); kq = int(np.argmax(e2_)); nv_ = i1 if e1_[i1] >= e2_[kq] else int(j2_[kq])
    idxR.append(nv_ if nv_ not in idxR else i1)
idxR = sorted(idxR); mejor = _costo(idxR)
for _ in range(6):                                     # refinamiento: deslizar puntos
    mj = False
    for pq in range(1, N_REST - 1):
        for dl in (-20, -10, -5, -2, 2, 5, 10, 20):
            cd = idxR.copy(); cd[pq] += dl
            if not (cd[pq - 1] < cd[pq] < cd[pq + 1]): continue
            cc_ = _costo(cd)
            if cc_ < mejor: idxR, mejor, mj = cd, cc_, True
    if not mj: break
PR, cR2, e1_, e2_, _ = _errores(idxR)
errR = ((e1_.mean() + e2_.mean()) / 2, max(e1_.max(), e2_.max()))

tmp[:] = 0                                            # silueta final: spline de la cabeza + cuerpo original
cv2.fillPoly(tmp, [np.vstack([cR2, [cR2[-1, 0], Y_ARC], [cR2[0, 0], Y_ARC]]).astype(np.int32)], 1)
fil_ = (np.arange(h)[:, None] <= Y_ARC)
Mf = ((tmp > 0) & fil_) | (mask & ~fil_)
# --- Textura de la zona azul = baja frecuencia (color y luz) + alta frecuencia (grano real de la piedra) ---
Tx = vista.copy()
_az = Mf & ~mask                                               # lo que la silueta restaurada agrega (zona azul + bordes)
_x0, _x1, _y1 = max(0, int(curva_az[:, 0].min()) - 30), min(w, XA + 60), min(h, Y_ARC + 90)
_fondo = ((~mask)[:_y1, _x0:_x1]).copy()                       # exterior: no sirve como fuente de color
_crop = vista[:_y1, _x0:_x1].copy(); _crop[_fondo] = 0
_rell = cv2.inpaint(_crop, (_fondo * 255).astype(np.uint8), 7, cv2.INPAINT_TELEA)
_rell = cv2.GaussianBlur(_rell, (0, 0), 5)                     # luz y color suaves, sin rayas del inpaint
Base = vista.astype(np.float32).copy()
_a_ = _az[:_y1, _x0:_x1]; Base[:_y1, _x0:_x1][_a_] = _rell[_a_]

# volumen: la piedra se oscurece suavemente hacia el borde exterior y se aclara hacia arriba (luz del sol)
_dist = cv2.distanceTransform(_az.astype(np.uint8), cv2.DIST_L2, 5)
_volumen = 1.0 - 0.28 * np.exp(-_dist / 14.0)
_ys = np.arange(h, dtype=np.float32)[:, None]
_luz = 1.0 + 0.10 * np.clip((140 - _ys) / 140, -0.5, 1)
Base = Base * (np.where(_az, _volumen * _luz, 1.0))[..., None]

# grano: banco de detalle (alta frecuencia) de la corona y del mechon conservados, cosido por parches (quilting)
_f = vista.astype(np.float32); _m = mask.astype(np.float32)
_lo = cv2.GaussianBlur(_f * _m[..., None], (0, 0), 5) / np.maximum(cv2.GaussianBlur(_m, (0, 0), 5), 1e-3)[..., None]
_alta = np.clip((_f - _lo) * _m[..., None], -28, 28)             # detalle fino, solo de piedra
PS, OV = 44, 16
_dentro = cv2.erode(mask.astype(np.uint8), np.ones((PS, PS), np.uint8)) > 0   # parche completo dentro de la piedra
_zonaf = np.zeros((h, w), bool); _zonaf[75:215, 420:650] = True; _zonaf[240:400, 360:440] = True
_en = (_alta ** 2).mean(axis=2)
_en = cv2.blur(_en, (PS, PS))                                    # energia local (evita grietas profundas)
_src = _dentro & _zonaf
_src &= _en < np.percentile(_en[_src], 70)
_rng = np.random.default_rng(7)
_cy, _cx = np.where(_src)
_by0, _by1 = np.where(_az.any(axis=1))[0][[0, -1]]; _bx0, _bx1 = np.where(_az.any(axis=0))[0][[0, -1]]
_by0 -= OV; _bx0 -= OV
_acc = np.zeros((h, w, 3), np.float32); _wsum = np.zeros((h, w), np.float32)
_hv = np.hanning(PS + 2)[1:-1]; _win = np.outer(_hv, _hv).astype(np.float32) + 1e-3
for py in range(_by0, _by1 + 1, PS - OV):
    for px in range(_bx0, _bx1 + 1, PS - OV):
        py2, px2 = min(py + PS, h), min(px + PS, w)
        if not _az[py:py2, px:px2].any(): continue
        mejor, cand = 1e18, None
        for _ in range(80):
            k = _rng.integers(len(_cy)); sy, sx = _cy[k] - PS // 2, _cx[k] - PS // 2
            if sy < 0 or sx < 0 or sy + PS > h or sx + PS > w: continue
            parche = _alta[sy:sy + PS, sx:sx + PS]
            ph, pw = py2 - py, px2 - px
            prev = _wsum[py:py2, px:px2] > 0.05
            if prev.any():
                est = _acc[py:py2, px:px2] / np.maximum(_wsum[py:py2, px:px2], 1e-3)[..., None]
                e = (((parche[:ph, :pw] - est) ** 2).sum(axis=2) * prev).sum() / prev.sum()
            else: e = _rng.random()
            if e < mejor: mejor, cand = e, parche
        if cand is None: continue
        ph, pw = py2 - py, px2 - px
        _acc[py:py2, px:px2] += cand[:ph, :pw] * _win[:ph, :pw, None]; _wsum[py:py2, px:px2] += _win[:ph, :pw]
HF = _acc / np.maximum(_wsum, 1e-3)[..., None]
_sd_src = _alta[_src].std(); _sd_new = HF[_az].std() + 1e-6
HF = np.clip(HF * (_sd_src / _sd_new) * 0.95, -28, 28)                                  # recupera el contraste perdido al mezclar parches
_A = cv2.GaussianBlur(_az.astype(np.float32), (0, 0), 2.0); _A = np.where(_az, 1.0, _A)
Tx = np.clip(Base + HF * _A[..., None], 0, 255).astype(np.uint8)
Tx[~(mask | azul)] = vista[~(mask | azul)]
yb = min(h, Y_ARC + 90)                               # pulido: solo la zona de la cabeza
Pu = Tx[:yb].copy()
for _ in range(5): Pu = cv2.bilateralFilter(Pu, 9, 55, 9)
Pu = cv2.addWeighted(Pu, 0.75, cv2.GaussianBlur(Pu, (0, 0), 6), 0.25, 0)
Pu = np.clip(Pu.astype(float) * 1.06 + 6, 0, 255)
Pu = PULIDO * Pu + (1 - PULIDO) * Tx[:yb]
wg = np.clip(1 - (np.arange(yb) - (Y_ARC + 20)) / 60.0, 0, 1)[:, None, None]
Tp = Tx.copy(); Tp[:yb] = (Pu * wg + Tx[:yb] * (1 - wg)).astype(np.uint8)
NEW = np.where(Mf[..., None], Tp, np.full((h, w, 3), 30, np.uint8))
OVL = np.zeros((h, w, 4), np.uint8); OVL[falta] = (40, 110, 255, 255)

# ---------- 2) Cámara y lienzo ----------
m1, m2 = 60, 25
hx0, hx1 = P[:, 0].min() - m1, P[:, 0].max() + m1
hy0, hy1 = P[:, 1].min() - m1, P[:, 1].max() + m1
bx0, bx1 = P[:, 0].min() - m2, P[:, 0].max() + m2
by0, by1 = P[:, 1].min() - m2, P[:, 1].max() + m2
full = np.array([0, w, h, 0.]); head = np.array([hx0, hx1, hy1, hy0])
cx0, cx1 = int(max(hx0, 0)), int(min(hx1, w)); cy0, cy1 = int(max(hy0, 0)), int(min(hy1, h))
rx0, rx1 = int(max(0, arco[:, 0].min() - 40)), int(min(w, arco[:, 0].max() + 40)); ry0, ry1 = 0, int(min(h, Y_ARC + 80))
head2 = np.array([rx0 - 20, rx1 + 20, ry1, ry0 - 10.])
def sobre2(base):
    out = ORIG.copy(); out[ry0:ry1, rx0:rx1] = base; return out
def mezcla2(A, B, a):
    return (A[ry0:ry1, rx0:rx1] * (1 - a) + B[ry0:ry1, rx0:rx1] * a).astype(np.uint8)
def cam(b): ax.set_xlim(b[0], b[1]); ax.set_ylim(b[2], b[3])
estado = {"k": None}
def poner(arr, clave=None):
    if clave is None or estado["k"] != clave:
        im.set_data(arr); estado["k"] = clave
def sobre(base):
    out = ORIG.copy(); out[cy0:cy1, cx0:cx1] = base; return out
def mezcla(A, B, a):
    return (A[cy0:cy1, cx0:cx1] * (1 - a) + B[cy0:cy1, cx0:cx1] * a).astype(np.uint8)

fig = plt.figure(figsize=(19.2, 10.8), facecolor=BG)
ax = fig.add_axes([0.02, 0.04, 0.62, 0.90], facecolor=BG)
pan = fig.add_axes([0.66, 0.04, 0.32, 0.90], facecolor=BG); pan.axis("off")
im = ax.imshow(vista); ov = ax.imshow(OVL); ov.set_alpha(0); ax.axis("off")
ax.set_aspect("equal", adjustable="datalim")
dyn = []

NOMBRES = ["Pieza original", "Zona seleccionada", "Puntos de control", "Primeros segmentos",
           "Spline completo", "Reconstrucción digital", "Reconstrucción: validación", "Resultado final"]
PASOS = [1, 2, 3, 4, 5, 6, 6, 7]
DUR = [5, 6, 8, 8, 8, 12, 12, 28]
T0 = np.concatenate([[0], np.cumsum(DUR)]); TOTAL = float(T0[-1])
cols = plt.cm.turbo(np.linspace(0.05, 0.95, n))[:, :3]

def ease(u): u = np.clip(u, 0, 1); return u * u * (3 - 2 * u)
def camara(a):
    b = full + (head - full) * a
    ax.set_xlim(b[0], b[1]); ax.set_ylim(b[2], b[3])
def T(x, y, s, **kw):
    kw.setdefault("va", "top"); kw.setdefault("color", "white")
    dyn.append(pan.text(x, y, s, transform=pan.transAxes, **kw))
def linea(xy, col, lw=3.5, alpha=1.0, glow=True, **kw):
    if len(xy) < 2: return
    if glow: dyn.append(ax.plot(xy[:, 0], xy[:, 1], color=col, lw=lw * 3, alpha=0.18, solid_capstyle="round")[0])
    dyn.append(ax.plot(xy[:, 0], xy[:, 1], color=col, lw=lw, alpha=alpha, solid_capstyle="round", **kw)[0])
def parcial(xy, f):
    k = int(len(xy) * float(np.clip(f, 0, 1)))
    return xy[:max(k, 0)]
def puntos(idx, xy, col=DOR, ms=9, labels=True):
    for i in idx:
        dyn.append(ax.plot(xy[i, 0], xy[i, 1], "o", color=col, ms=ms, mec="white", mew=1.2)[0])
        if labels: dyn.append(ax.text(xy[i, 0] + 12, xy[i, 1] - 14, f"P{i+1}", color="white", fontsize=13, weight="bold"))
def poli_parcial(pts, f):
    L = np.r_[0, np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))]
    tgt = L[-1] * float(np.clip(f, 0, 1)); k = np.searchsorted(L, tgt)
    if k == 0: return pts[:1]
    a = (tgt - L[k - 1]) / (L[k] - L[k - 1] + 1e-9)
    return np.vstack([pts[:k], pts[k - 1] + a * (pts[k] - pts[k - 1])])
def formula(i):
    a, b, cc, dd = c[3, i, 0], c[2, i, 0], c[1, i, 0], c[0, i, 0]
    ay, by_, cy, dy = h - c[3, i, 1], -c[2, i, 1], -c[1, i, 1], -c[0, i, 1]   # y hacia arriba
    sx = rf"$X_{{{i+1}}}(t)={a:.2f}{b:+.3f}\,\Delta t{cc:+.4f}\,\Delta t^2{dd:+.5f}\,\Delta t^3$"
    sy = rf"$Y_{{{i+1}}}(t)={ay:.2f}{by_:+.3f}\,\Delta t{cy:+.4f}\,\Delta t^2{dy:+.5f}\,\Delta t^3$"
    return sx, sy

# ---------- 3) Un fotograma = función del tiempo ----------
def frame(time):
    for a in dyn: a.remove()
    dyn.clear()
    k = min(int(np.searchsorted(T0, time, side="right") - 1), 7); u = time - T0[k]
    ov.set_alpha(0)

    if k == 0 or (k == 1 and u < 2): camara(0)
    elif k == 1: camara(ease((u - 2) / 3))
    else: camara(1)
    im.set_alpha(ease(u / 1.5) if k == 0 else 1.0)
    if k < 6: poner(ORIG, 'orig')

    T(0.0, 0.99, f"PASO {PASOS[k]} DE 7", color=DOR, fontsize=15, weight="bold")
    T(0.0, 0.94, NOMBRES[k], fontsize=27, weight="bold")
    T(0.0, 0.03, "●" * PASOS[k] + "○" * (7 - PASOS[k]), color=DOR, fontsize=18, va="bottom")

    if k == 0:
        T(0.0, 0.82, "Monolito Fraile", fontsize=22, color=DOR)
        T(0.0, 0.76, "Escultura lítica · Tiwanaku, Bolivia", fontsize=15)
        if u > 2.5: T(0.0, 0.66, "Objetivo: reconstruir parte de su contorno\nmediante splines cúbicos", fontsize=15)

    elif k == 1:
        box = np.array([[bx0, by0], [bx1, by0], [bx1, by1], [bx0, by1], [bx0, by0]])
        linea(poli_parcial(box, ease((u - 0.5) / 1.5)), DOR, lw=3.5)
        if u > 2: T(0.0, 0.82, "Zona elegida:", fontsize=17, color=DOR)
        if u > 2: T(0.0, 0.77, "contorno de la cabeza\ny el cuello", fontsize=17)
        if u > 3.5: T(0.0, 0.62, "Se busca reconstruir la parte\nfracturada de la cabeza", fontsize=15)

    elif k == 2:
        nv = int(np.clip((u - 0.8) / 0.4 + 1, 0, n + 1))
        puntos(range(nv), P, ms=9 + 7 * (1 - ease((u - 0.8) % 0.4 / 0.4)) if 0 < nv <= n else 9)
        T(0.0, 0.84, r"$P_i=(x_i,\,y_i)$   ·   15 puntos", fontsize=18, color=DOR)
        for i in range(nv):
            T(0.0, 0.78 - i * 0.045, f"P{i+1:<2d} = ({P[i,0]:7.1f}, {h - P[i,1]:7.1f})", fontsize=13.5, family="monospace")

    elif k == 3:
        puntos(range(n + 1), P, ms=8, labels=False)
        s = int(np.clip((u - 1) // 2, 0, 2))
        for i in range(3):
            f = ease((u - (1 + 2 * i)) / 1.6)
            linea(parcial(seg[i], f), cols[i], lw=4)
        T(0.0, 0.84, "Un polinomio cúbico distinto\npor cada intervalo", fontsize=17)
        if u > 1:
            sx, sy = formula(s)
            T(0.0, 0.66, f"Tramo {s+1}: de P{s+1} a P{s+2}", fontsize=17, color=cols[s])
            T(0.0, 0.60, sx, fontsize=12.5); T(0.0, 0.55, sy, fontsize=12.5)
            T(0.0, 0.49, r"$\Delta t = t - t_i$", fontsize=14, color="#aaaaaa")

    elif k == 4:
        puntos(range(n + 1), P, ms=8, labels=False)
        mez = ease((u - 5.2) / 1.3)
        cnt = 3
        for i in range(n):
            f = 1.0 if i < 3 else ease((u - (0.5 + 0.4 * (i - 3))) / 0.5)
            if f > 0: cnt = max(cnt, i + 1 if f >= 1 else cnt)
            linea(parcial(seg[i], f), cols[i] * (1 - mez) + np.array(matplotlib.colors.to_rgb(CIAN)) * mez, lw=4)
        if u < 5.2:
            T(0.0, 0.84, "Se agregan los tramos\nrestantes", fontsize=17); T(0.0, 0.70, f"Tramos unidos: {cnt} / 14", fontsize=17, color=DOR)
        else:
            T(0.0, 0.84, "Spline completo:\n14 cúbicos unidos", fontsize=17, color=DOR)
        if u > 6.3:
            T(0.0, 0.62, "Continuidad en cada nodo", fontsize=16, color=DOR)
            T(0.0, 0.57, rf"$C^0$  misma posición     (error {e0:.0e})", fontsize=13.5)
            T(0.0, 0.52, rf"$C^1$  misma tangente    (error {e1:.0e})", fontsize=13.5)
            T(0.0, 0.47, rf"$C^2$  misma curvatura   (error {e2:.0e})", fontsize=13.5)

    elif k == 5:
        linea(ref, "white", lw=1.6, alpha=0.55, glow=False, ls="--")
        puntos([i for i in range(n + 1) if i not in PERDIDOS], P, ms=8, labels=False)
        if u > 0.3:
            p = 1 + 0.25 * np.sin(u * 8) if u < 2 else 1
            for i in PERDIDOS:
                dyn.append(ax.plot(P[i, 0], P[i, 1], "x", color=ROJO, ms=16 * p, mew=4)[0])
        else:
            puntos(PERDIDOS, P, ms=8, labels=False)
        fA, fB = ease((u - 2) / 3.5), ease((u - 6) / 3.5)
        linea(parcial(cA, fA), CIAN, lw=4)
        if u > 5.5:
            dyn.append(ax.plot([xc, xc], [hy0, hy1], color="#999999", ls=":", lw=1.5)[0])
        if u > 6.3:
            for i in PERDIDOS:
                dyn.append(ax.plot(PB[i, 0], PB[i, 1], "s", color=MAG, ms=10, mec="white")[0])
        linea(parcial(cB, fB), MAG, lw=4)
        if u < 2:
            T(0.0, 0.84, "Se simula el daño:\nse pierden P10, P11 y P12", fontsize=17, color=ROJO)
        elif u < 6:
            T(0.0, 0.84, "Plan A: puente directo", fontsize=19, color=CIAN)
            T(0.0, 0.78, "El spline une los puntos\nsanos vecinos", fontsize=15)
        else:
            T(0.0, 0.84, "Plan B: simetría", fontsize=19, color=MAG)
            T(0.0, 0.78, f"Se reflejan puntos del lado\nderecho (eje x = {xc:.0f})", fontsize=15)
        if u > 9.5:
            T(0.0, 0.55, f"Plan A: error medio {eA[0]:.1f} px", fontsize=16, color=CIAN)
            T(0.0, 0.50, f"Plan B: error medio {eB[0]:.1f} px", fontsize=16, color=MAG)
        if u > 10.5:
            T(0.0, 0.42, f"Se usa el Plan {gan} para\nreconstruir el monolito", fontsize=15, color=DOR)

    elif k == 6:
        if u < 1.5: poner(sobre(mezcla(ORIG, DAM, ease(u / 1.2))))
        elif u < 4.5: poner(sobre(mezcla(DAM, REC, ease((u - 1.5) / 2.5))))
        elif u < 5.5: poner(sobre(REC[cy0:cy1, cx0:cx1]))
        elif u < 8.5:
            xl = int(cx0 + (cx1 - cx0) * ease((u - 5.5) / 3))
            comp = REC[cy0:cy1, cx0:cx1].copy(); comp[:, xl - cx0:] = ORIG[cy0:cy1, xl:cx1]
            poner(sobre(comp))
            dyn.append(ax.plot([xl, xl], [hy0, hy1], color="white", lw=2.5)[0])
        else: poner(sobre(REC[cy0:cy1, cx0:cx1]))
        if u < 1.5:
            for i in PERDIDOS: dyn.append(ax.plot(P[i, 0], P[i, 1], "x", color=ROJO, ms=16, mew=4)[0])
        if u >= 1.5: linea(cR, CIAN, lw=3)
        if 4.5 <= u < 8.5: linea(ref, "white", lw=1.6, alpha=0.6, glow=False, ls="--")
        if u < 1.5:
            T(0.0, 0.84, "Validación: se simula\nuna pérdida de material", fontsize=19, color=ROJO)
        elif u < 5.5:
            T(0.0, 0.84, "Relleno guiado\npor el spline", fontsize=19, color=CIAN)
            T(0.0, 0.72, f"El Plan {gan} define el nuevo borde.\nEl material se estima y se marca\nen tono cian.", fontsize=15)
        elif u < 8.5:
            T(0.0, 0.84, "Comparación", fontsize=19, color=DOR)
            T(0.0, 0.78, "Izquierda de la línea: reconstruido\nDerecha: foto real\nLínea punteada: contorno real", fontsize=15)
        else:
            T(0.0, 0.84, "El método funciona", fontsize=21, color=DOR, weight="bold")
            T(0.0, 0.77, f"Plan {gan}: error medio {eR[0]:.1f} px\n(máx. {eR[1]:.1f} px) frente al contorno real", fontsize=15)
            if u > 10: T(0.0, 0.62, "Ahora lo aplicamos a la fractura\nreal de la pieza.", fontsize=15, color=DOR)

    else:
        if u < 1.5: cam(head + (head2 - head) * ease(u / 1.5))
        elif u < 21: cam(head2)
        elif u < 24.5: cam(head2 + (full - head2) * ease((u - 21) / 3.5))
        else: cam(full)

        if u < 14: poner(ORIG, 'orig2')
        elif u < 17.5: poner(sobre2(mezcla2(ORIG, NEW, ease((u - 14) / 3.5))))
        elif u < 18: poner(sobre2(NEW[ry0:ry1, rx0:rx1]))
        elif u < 21:
            xl = int(rx0 + (rx1 - rx0) * ease((u - 18) / 3))
            comp = NEW[ry0:ry1, rx0:rx1].copy(); comp[:, xl - rx0:] = ORIG[ry0:ry1, xl:rx1]
            poner(sobre2(comp))
            dyn.append(ax.plot([xl, xl], [ry0, ry1], color="white", lw=2.5)[0])
        else: poner(sobre2(NEW[ry0:ry1, rx0:rx1]))

        if 2.5 <= u < 14: ov.set_alpha(0.55 * ease((u - 2.5) / 1.5))
        elif 14 <= u < 17.5: ov.set_alpha(0.55 * (1 - ease((u - 14) / 3.5)))
        if 0.5 <= u < 6.5:                                 # zona azul: puntos de control + spline cubico
            linea(parcial(curva_az, ease((u - 0.5) / 2.0)), AZUL, lw=3, glow=False)
            if u >= 2.5: puntos(range(len(PUNTOS_AZUL)), PUNTOS_AZUL, col=AZUL, ms=7, labels=False)
        nv = int(np.clip((u - 6.5) / 0.3 + 1, 0, N_REST)) if u >= 6.5 else 0
        if nv and u < 21: puntos(range(nv), PR, ms=8, labels=False)
        if u >= 11:
            linea(parcial(cR2, ease((u - 11) / 3)), CIAN, lw=4 if u < 21 else 2, glow=u < 21)

        if u < 2.5:
            T(0.0, 0.84, "Zona dañada", fontsize=19, color=AZUL)
            if u > 1.5: T(0.0, 0.77, "La parte superior izquierda de\nla cabeza perdió material.", fontsize=15)
        elif u < 6.5:
            T(0.0, 0.84, "Material faltante", fontsize=19, color=AZUL)
            T(0.0, 0.77, "Spline cúbico natural sobre 8\npuntos del borde exterior\n(zona azul).", fontsize=15)
        elif u < 11:
            T(0.0, 0.84, "Contorno restaurado", fontsize=19, color=DOR)
            T(0.0, 0.77, "Puntos de control sobre la\nsilueta restaurada.", fontsize=15)
            T(0.0, 0.66, f"Puntos: {nv} / {N_REST}", fontsize=17, color=DOR)
        elif u < 14:
            T(0.0, 0.84, "Spline cúbico", fontsize=19, color=CIAN)
            T(0.0, 0.77, "Los 14 tramos se unen con\ncontinuidad C²: sin quiebres.", fontsize=15)
            T(0.0, 0.66, f"Error medio {errR[0]:.1f} px\n(máx. {errR[1]:.1f} px)", fontsize=15)
        elif u < 18:
            T(0.0, 0.84, "Piedra restaurada", fontsize=19, color=DOR)
            T(0.0, 0.77, "El material faltante se completa\ncon la textura de la piedra\nvecina y la superficie se pule.", fontsize=15)
        elif u < 21:
            T(0.0, 0.84, "Comparación", fontsize=19, color=DOR)
            T(0.0, 0.78, "Izquierda de la línea: restaurado\nDerecha: estado actual", fontsize=15)
        elif u < 24.5:
            T(0.0, 0.84, "Monolito restaurado", fontsize=21, color=DOR, weight="bold")
        else:
            T(0.0, 0.84, "Monolito restaurado", fontsize=21, color=DOR, weight="bold")
            T(0.0, 0.77, "Cómo pudo verse recién tallado:\nzona azul + 15 puntos + spline.", fontsize=15)
            if u > 25.5: T(0.0, 0.62, "Es una hipótesis: no existe la\npieza original para medir el\nerror real.", fontsize=15, color=ROJO)

def main():
    nfr = int(TOTAL * FPS) + FPS
    wr = FFMpegWriter(fps=FPS, codec="libx264", extra_args=["-pix_fmt", "yuv420p", "-crf", "20", "-movflags", "+faststart"])
    with wr.saving(fig, "animacion_monolito.mp4", DPI):
        for f in range(nfr):
            frame(min(f / FPS, TOTAL - 1e-3)); wr.grab_frame()
            if f % FPS == 0: print(f"  {f / nfr:5.0%}", end="\r")
    print("Listo: animacion_monolito.mp4")

if __name__ == "__main__":
    main()

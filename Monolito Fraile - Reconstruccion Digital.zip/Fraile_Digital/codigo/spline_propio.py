import numpy as np
from scipy.interpolate import CubicSpline

# 1) Cargar los puntos de control Pi = (xi, yi)
P = np.loadtxt("puntos.csv", delimiter=",", skiprows=1)
n = len(P) - 1                                    # número de tramos

# 2) Parámetro t (centrípeto, igual que en digitalizar.py)
d = np.linalg.norm(np.diff(P, axis=0), axis=1)
t = np.concatenate([[0], np.cumsum(np.sqrt(d))])
h = np.diff(t)

# 3) Spline cúbico natural implementado desde cero (para una coordenada)
def spline_natural(t, y):
    n = len(t) - 1
    h = np.diff(t)
    A = np.zeros((n + 1, n + 1))                  # sistema tridiagonal
    r = np.zeros(n + 1)
    A[0, 0] = A[n, n] = 1                         # c_0 = c_n = 0 (natural)
    for i in range(1, n):
        A[i, i - 1] = h[i - 1]
        A[i, i]     = 2 * (h[i - 1] + h[i])
        A[i, i + 1] = h[i]
        r[i] = 3 * ((y[i + 1] - y[i]) / h[i] - (y[i] - y[i - 1]) / h[i - 1])
    c = np.linalg.solve(A, r)
    a = y[:-1]
    b = (y[1:] - y[:-1]) / h - h * (2 * c[:-1] + c[1:]) / 3
    dd = (c[1:] - c[:-1]) / (3 * h)
    return a, b, c[:-1], dd                       # coeficientes de cada tramo

ax_, bx, cx, dx = spline_natural(t, P[:, 0])      # X_i(t)
ay_, by, cy, dy = spline_natural(t, P[:, 1])      # Y_i(t)

# 4) Evaluar el tramo i en el parámetro s (valor, 1ª y 2ª derivada)
def evalua(i, s):
    u = s - t[i]
    X  = ax_[i] + bx[i]*u + cx[i]*u**2 + dx[i]*u**3
    Y  = ay_[i] + by[i]*u + cy[i]*u**2 + dy[i]*u**3
    X1 = bx[i] + 2*cx[i]*u + 3*dx[i]*u**2
    Y1 = by[i] + 2*cy[i]*u + 3*dy[i]*u**2
    X2 = 2*cx[i] + 6*dx[i]*u
    Y2 = 2*cy[i] + 6*dy[i]*u
    return np.array([X, Y]), np.array([X1, Y1]), np.array([X2, Y2])

# 5) Verificación de continuidad en los nodos interiores
e0 = e1 = e2 = 0
for i in range(1, n):
    izq = evalua(i - 1, t[i])                     # fin del tramo anterior
    der = evalua(i, t[i])                         # inicio del tramo siguiente
    e0 = max(e0, np.linalg.norm(izq[0] - der[0]))
    e1 = max(e1, np.linalg.norm(izq[1] - der[1]))
    e2 = max(e2, np.linalg.norm(izq[2] - der[2]))
print(f"Tramos: {n}")
print(f"C0 (posición):   error máx = {e0:.2e}")
print(f"C1 (tangente):   error máx = {e1:.2e}")
print(f"C2 (curvatura):  error máx = {e2:.2e}")

# 6) Comparación con SciPy (validación independiente)
ref = CubicSpline(t, P, bc_type="natural")
ts = np.linspace(0, t[-1], 2000)
mio = np.array([evalua(min(np.searchsorted(t, s, side="right") - 1, n - 1), s)[0] for s in ts])
print(f"Diferencia vs SciPy: {np.abs(mio - ref(ts)).max():.2e} px")

# 7) Guardar coeficientes (para mostrar la tabla en el video)
tabla = np.column_stack([np.arange(1, n + 1), t[:-1], t[1:], ax_, bx, cx, dx, ay_, by, cy, dy])
np.savetxt("coeficientes.csv", tabla, delimiter=",", comments="",
           header="tramo,t_ini,t_fin,ax,bx,cx,dx,ay,by,cy,dy")
print("\nTramo 1 (para mostrar en pantalla):")
print(f"X1(t) = {ax_[0]:.2f} + {bx[0]:.3f}(t-{t[0]:.2f}) + {cx[0]:.4f}(t-{t[0]:.2f})² + {dx[0]:.5f}(t-{t[0]:.2f})³")
print(f"Y1(t) = {ay_[0]:.2f} + {by[0]:.3f}(t-{t[0]:.2f}) + {cy[0]:.4f}(t-{t[0]:.2f})² + {dy[0]:.5f}(t-{t[0]:.2f})³")
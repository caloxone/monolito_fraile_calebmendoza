"""Contenido del informe. Una sola fuente para la hoja HTML de la web y para el PDF.

Cada bloque es una tupla:
  ("h2", texto) · ("h3", texto) · ("p", html) · ("formula", html) · ("ul", [html, ...])
  ("tabla", [encabezados], [[celdas]]) · ("fig", ruta_static, pie)
El HTML permitido es mínimo (<i>, <b>, <sub>, <sup>) para que el PDF lo entienda igual.
Se escribe solo con caracteres Latin-1 (el PDF usa tipografías estándar).
"""
from __future__ import annotations


def _f(v: float, d: int = 1) -> str:
    return f"{v:,.{d}f}".replace(",", " ")


def construir(s, cfg, val, cont):
    n = s.n
    tabla_puntos = [[f"P{i + 1}", _f(x), _f(y)] for i, (x, y) in enumerate(s.puntos)]
    azul = [(470, 62), (440, 68), (388, 80), (361, 107), (343, 153), (340, 214), (343, 259), (347, 285)]
    tabla_azul = [[f"A{i + 1}", str(x), str(y)] for i, (x, y) in enumerate(azul)]

    B = []
    B += [("h2", "1. Objetivo"),
          ("p", "Reconstruir digitalmente una parte del contorno del <b>Monolito Fraile</b> (Tiwanaku) mediante interpolaci&oacute;n "
                "con splines c&uacute;bicos. La secuencia de trabajo es: pieza arqueol&oacute;gica, puntos de control, spline c&uacute;bico, "
                "reconstrucci&oacute;n y animaci&oacute;n. La animaci&oacute;n no se dibuja a mano: se genera a partir del modelo matem&aacute;tico."),
          ("h2", "2. Pieza y zona seleccionada"),
          ("p", "El Monolito Fraile es una escultura l&iacute;tica antropomorfa de la cultura Tiwanaku. Se eligi&oacute; la <b>cabeza y el cuello</b> "
                "porque su contorno es curvo y se distingue con claridad del fondo, y porque la parte superior izquierda de la cabeza "
                "est&aacute; deteriorada: es una secci&oacute;n incompleta susceptible de reconstrucci&oacute;n."),
          ("p", "El contorno sube por el lado derecho, cruza la coronilla y baja por el lado izquierdo. Para una misma coordenada x hay dos valores de y, "
                "as&iacute; que no es una funci&oacute;n y(x). Por eso se usa un spline c&uacute;bico <b>param&eacute;trico</b>."),
          ("fig", "img/escena_contexto.jpg", "Figura 1. La pieza completa, la zona elegida (recuadro dorado) y los puntos de control sobre el contorno."),
          ("h2", "3. Obtenci&oacute;n de los puntos de control"),
          ("p", f"A partir de la fotograf&iacute;a frontal se recorri&oacute; el borde de la cabeza y se marcaron <b>{len(s.puntos)} puntos</b> "
                "P<sub>i</sub> = (x<sub>i</sub>, y<sub>i</sub>), de P1 (cuello derecho) a P15 (cuello izquierdo), pasando por la coronilla (P8). "
                "Las coordenadas est&aacute;n en p&iacute;xeles de la imagen, con el eje y hacia arriba (y = 1516 - y de pantalla)."),
          ("tabla", ["Punto", "x (px)", "y (px)"], tabla_puntos),
          ("h2", "4. Spline c&uacute;bico param&eacute;trico"),
          ("p", "Cada punto recibe un valor del par&aacute;metro t con la parametrizaci&oacute;n centr&iacute;peta, que crece con la ra&iacute;z de la distancia entre puntos:"),
          ("formula", "t<sub>0</sub> = 0, &nbsp; t<sub>i+1</sub> = t<sub>i</sub> + sqrt( |P<sub>i+1</sub> - P<sub>i</sub>| )"),
          ("p", f"En cada uno de los {n} intervalos [t<sub>i</sub>, t<sub>i+1</sub>] las coordenadas son polinomios c&uacute;bicos:"),
          ("formula", "X<sub>i</sub>(t) = a<sub>x,i</sub> + b<sub>x,i</sub>(t - t<sub>i</sub>) + c<sub>x,i</sub>(t - t<sub>i</sub>)<sup>2</sup> + d<sub>x,i</sub>(t - t<sub>i</sub>)<sup>3</sup>"),
          ("formula", "Y<sub>i</sub>(t) = a<sub>y,i</sub> + b<sub>y,i</sub>(t - t<sub>i</sub>) + c<sub>y,i</sub>(t - t<sub>i</sub>)<sup>2</sup> + d<sub>y,i</sub>(t - t<sub>i</sub>)<sup>3</sup>"),
          ("p", f"Por coordenada hay 4 &middot; {n} = {4 * n} incógnitas. Se imponen: pasar por los puntos ({2 * n} condiciones), igualar la primera derivada ({n - 1}) y la segunda ({n - 1}) "
                f"en los nodos interiores, y dos condiciones naturales (segunda derivada nula en los extremos). Con h<sub>i</sub> = t<sub>i+1</sub> - t<sub>i</sub>, todo se reduce a un sistema tridiagonal en los c<sub>i</sub>:"),
          ("formula", "h<sub>i-1</sub> c<sub>i-1</sub> + 2(h<sub>i-1</sub> + h<sub>i</sub>) c<sub>i</sub> + h<sub>i</sub> c<sub>i+1</sub> = 3 [ (y<sub>i+1</sub> - y<sub>i</sub>)/h<sub>i</sub> - (y<sub>i</sub> - y<sub>i-1</sub>)/h<sub>i-1</sub> ]"),
          ("p", "con c<sub>0</sub> = c<sub>n</sub> = 0. Luego a<sub>i</sub> = y<sub>i</sub>, b<sub>i</sub> = (y<sub>i+1</sub> - y<sub>i</sub>)/h<sub>i</sub> - h<sub>i</sub>(2c<sub>i</sub> + c<sub>i+1</sub>)/3 y d<sub>i</sub> = (c<sub>i+1</sub> - c<sub>i</sub>)/(3h<sub>i</sub>). "
                f"El sistema de {n - 1} x {n - 1} se resuelve con el algoritmo de Thomas, una vez para X y otra para Y."),
          ("h2", "5. Continuidad C<sup>0</sup>, C<sup>1</sup> y C<sup>2</sup>"),
          ("p", "Los polinomios se unen formando una curva continua y suave. En cada nodo interior los dos tramos vecinos coinciden en posici&oacute;n (C<sup>0</sup>: sin saltos), "
                "en tangente (C<sup>1</sup>: sin esquinas) y en curvatura (C<sup>2</sup>: sin cambios bruscos al curvar). Se verific&oacute; num&eacute;ricamente en los "
                f"{n - 1} nodos interiores:"),
          ("tabla", ["Condici&oacute;n", "Qu&eacute; se compara", "Error m&aacute;ximo"],
           [["C0", "posici&oacute;n S(t)", f"{cont['C0']:.1e}"], ["C1", "primera derivada S'(t)", f"{cont['C1']:.1e}"],
            ["C2", "segunda derivada S''(t)", f"{cont['C2']:.1e}"]]),
          ("p", "Los errores est&aacute;n en el orden de la precisi&oacute;n de la m&aacute;quina. Adem&aacute;s, el spline coincide con la implementaci&oacute;n de SciPy "
                "(diferencia m&aacute;xima de 4.6e-13 px) y pasa exactamente por los puntos de control."),
          ("h2", "6. Reconstrucci&oacute;n digital"),
          ("p", "La reconstrucci&oacute;n se muestra en 7 pasos: (1) pieza original, (2) zona seleccionada, (3) puntos de control, (4) primeros segmentos, "
                "(5) uni&oacute;n de segmentos, (6) reconstrucci&oacute;n digital y (7) resultado final."),
          ("p", "El material que falta es la parte superior izquierda de la cabeza (zona azul). Su borde exterior se defini&oacute; con 8 puntos de control y un spline c&uacute;bico "
                "natural. La zona se rellen&oacute; con la textura de la piedra vecina, y sobre la silueta restaurada se ajust&oacute; un segundo spline de 15 puntos."),
          ("tabla", ["Punto", "x (px)", "y (px, de pantalla)"], tabla_azul),
          ("p", "Para estos 8 puntos las coordenadas se dan en el sistema de la imagen (y hacia abajo), igual que en el c&oacute;digo."),
          ("fig", "img/paso7c.jpg", "Figura 2. Comparaci&oacute;n: a la izquierda de la l&iacute;nea, la pieza restaurada; a la derecha, su estado actual."),
          ("fig", "img/paso7d.jpg", "Figura 3. Resultado final sobre el monolito completo."),
          ("h2", "7. Validaci&oacute;n del m&eacute;todo"),
          ("p", "Como no existe la pieza original, se valid&oacute; la t&eacute;cnica en una zona conservada: se ocultaron P10, P11 y P12 y se reconstruyeron de dos formas, "
                "comparando contra el contorno real."),
          ("tabla", ["Plan", "Idea", "Error medio", "Error m&aacute;ximo"],
           [["A", "Puente directo del spline entre P9 y P13", f"{val['plan_a']['medio']} px", f"{val['plan_a']['maximo']} px"],
            ["B", "Reflejar los puntos respecto de un eje de simetr&iacute;a", f"{val['plan_b']['medio']} px", f"{val['plan_b']['maximo']} px"]]),
          ("p", "El puente directo del spline fue m&aacute;s preciso que suponer simetr&iacute;a, y ese es el criterio con que se complet&oacute; la zona dañada. "
                f"El spline final de 15 puntos se ajusta a la silueta restaurada con un error medio de {val['restauracion']['medio']} px (m&aacute;ximo {val['restauracion']['maximo']} px)."),
          ("fig", "img/comparacion_planes.jpg", "Figura 4. Validaci&oacute;n: contorno original, Plan A (puente directo) y Plan B (simetr&iacute;a)."),
          ("h2", "8. Animaci&oacute;n"),
          ("p", "El video de 1 min 27 s (1280 x 720, 20 cuadros por segundo) se genera cuadro a cuadro desde el modelo: aparecen los puntos, se trazan los segmentos, "
                "se une el spline completo y la pieza pasa de su estado actual a la reconstrucci&oacute;n, con una comparaci&oacute;n final lado a lado."),
          ("h2", "9. Conclusiones"),
          ("ul", ["<b>Qu&eacute; se reconstruy&oacute;:</b> la parte superior izquierda de la cabeza del Monolito Fraile y su contorno completo con 15 puntos.",
                  "<b>Utilidad de los splines c&uacute;bicos:</b> dan una curva suave (C<sup>2</sup>) que pasa por los puntos, con un c&aacute;lculo liviano (un sistema tridiagonal) y coeficientes que se pueden mostrar y verificar.",
                  "<b>Limitaci&oacute;n:</b> es una hip&oacute;tesis. Sin la pieza original no se puede medir el error real de la zona restaurada, y la textura agregada es una estimaci&oacute;n visual.",
                  "<b>Aplicaci&oacute;n futura:</b> extender el m&eacute;todo a otras piezas fragmentadas de Tiwanaku, y pasar del contorno 2D a perfiles de revoluci&oacute;n para generar modelos 3D."]),
          ("h2", "10. Archivos del proyecto"),
          ("ul", ["<b>digitalizar.py</b>: carga la imagen, ubica los puntos y arma la escena de contexto.",
                  "<b>spline_propio.py</b>: spline natural desde cero y verificaci&oacute;n de continuidad.",
                  "<b>reconstruccion.py</b>: validaci&oacute;n con p&eacute;rdida de tres puntos (Plan A y Plan B).",
                  "<b>animacion.py</b>: restauraci&oacute;n de la zona azul y generaci&oacute;n del video.",
                  "<b>puntos.csv</b> y <b>coeficientes.csv</b>: los datos del modelo."]),
          ]
    return B

"""Genera el informe en PDF (static/informe/Informe_Reconstruccion_Monolito_Fraile.pdf).

Uso:  python generar_informe.py
La app también lo genera sola si falta el archivo o si cambiaste config.py.
Requiere: reportlab (pip install reportlab).
"""
from __future__ import annotations

import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
SALIDA = BASE / "static" / "informe" / "Informe_Reconstruccion_Monolito_Fraile.pdf"


def generar(s, val, salida: Path = SALIDA) -> Path:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_JUSTIFY
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether, PageTemplate, Paragraph,
                                    Spacer, Table, TableStyle, ListFlowable, ListItem)
    from PIL import Image as PILImage

    import config
    import informe_contenido

    bloques = informe_contenido.construir(s, config, val, s.continuidad())

    VINO, FUCSIA, TINTA, ORO = colors.HexColor("#5a1f4a"), colors.HexColor("#e8347f"), colors.HexColor("#2b1d33"), colors.HexColor("#c9a64a")
    HILOS = ["#d3303d", "#f7b92b", "#1fbdb1", "#e8347f", "#4cab55", "#8a56c9", "#3d83f0"]
    est = {
        "p": ParagraphStyle("p", fontName="Times-Roman", fontSize=10.8, leading=15.5, alignment=TA_JUSTIFY, textColor=TINTA, spaceAfter=6),
        "h2": ParagraphStyle("h2", fontName="Times-BoldItalic", fontSize=16, leading=20, textColor=VINO, spaceBefore=14, spaceAfter=6, keepWithNext=1),
        "h3": ParagraphStyle("h3", fontName="Times-Bold", fontSize=12, leading=15, textColor=TINTA, spaceBefore=8, spaceAfter=4, keepWithNext=1),
        "f": ParagraphStyle("f", fontName="Times-Italic", fontSize=11.5, leading=17, textColor=TINTA, leftIndent=10, borderPadding=(6, 6, 6, 10), backColor=colors.HexColor("#efe4cc"), spaceBefore=4, spaceAfter=10),
        "cap": ParagraphStyle("cap", fontName="Courier", fontSize=8.5, leading=11, textColor=colors.HexColor("#6b5a72"), spaceAfter=8),
        "celda": ParagraphStyle("celda", fontName="Times-Roman", fontSize=9.5, leading=12, textColor=TINTA),
        "celdah": ParagraphStyle("celdah", fontName="Times-Bold", fontSize=9.5, leading=12, textColor=TINTA),
        "tit": ParagraphStyle("tit", fontName="Times-BoldItalic", fontSize=26, leading=30, textColor=VINO, spaceAfter=14),
        "dato": ParagraphStyle("dato", fontName="Times-Roman", fontSize=12, leading=18, textColor=TINTA),
    }

    def md(t: str) -> str:
        t = re.sub(r"</?(?:i|I)>", lambda m: m.group(0).lower(), t)
        return t.replace("<sup>", "<super>").replace("</sup>", "</super>")

    def franja(c, x, y, w, h):
        n = len(HILOS) * 3
        for i in range(n):
            c.setFillColor(colors.HexColor(HILOS[(i * 3) % len(HILOS)]) if i % 3 else colors.HexColor(HILOS[(i // 3) % len(HILOS)]))
            c.rect(x + w * i / n, y, w / n + 0.3, h, stroke=0, fill=1)

    def pagina(c, doc):
        c.saveState()
        franja(c, 0, A4[1] - 8 * mm, A4[0], 8 * mm)
        c.setFont("Courier", 8); c.setFillColor(colors.HexColor("#6b5a72"))
        c.drawString(20 * mm, 12 * mm, f"{config.ESTUDIANTE} - {config.CURSO}")
        c.drawRightString(A4[0] - 20 * mm, 12 * mm, f"Pagina {doc.page}")
        c.restoreState()

    salida.parent.mkdir(parents=True, exist_ok=True)
    doc = BaseDocTemplate(str(salida), pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=22 * mm, bottomMargin=20 * mm,
                          title=config.TITULO_TRABAJO, author=config.ESTUDIANTE)
    doc.addPageTemplates([PageTemplate(id="p", frames=[Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="f")], onPage=pagina)])
    ancho = doc.width

    h = [Spacer(1, 10 * mm), Paragraph(md(config.TITULO_TRABAJO), est["tit"])]
    for etiqueta, valor in [("Estudiante", config.ESTUDIANTE), ("Curso", config.CURSO), ("Docente", config.DOCENTE), ("Fecha", config.FECHA), ("Video", config.YOUTUBE_URL)]:
        if valor:
            h.append(Paragraph(f"<b>{etiqueta}:</b> {valor}", est["dato"]))
    h.append(Spacer(1, 8 * mm))

    for b in bloques:
        tipo = b[0]
        if tipo == "h2":
            h.append(Paragraph(md(b[1]), est["h2"]))
        elif tipo == "h3":
            h.append(Paragraph(md(b[1]), est["h3"]))
        elif tipo == "p":
            h.append(Paragraph(md(b[1]), est["p"]))
        elif tipo == "formula":
            h.append(Paragraph(md(b[1]), est["f"]))
        elif tipo == "ul":
            h.append(ListFlowable([ListItem(Paragraph(md(i), est["p"]), leftIndent=14) for i in b[1]], bulletType="bullet", start="\u2022", leftIndent=14))
        elif tipo == "tabla":
            datos = [[Paragraph(md(x), est["celdah"]) for x in b[1]]] + [[Paragraph(md(str(x)), est["celda"]) for x in fila] for fila in b[2]]
            t = Table(datos, repeatRows=1, hAlign="LEFT", colWidths=None)
            t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e6d8b8")), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d4c39b")),
                                   ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
            h += [t, Spacer(1, 8)]
        elif tipo == "fig":
            ruta = BASE / "static" / b[1]
            w, hh = PILImage.open(ruta).size
            ancho_img = min(ancho, 150 * mm)
            h.append(KeepTogether([Image(str(ruta), width=ancho_img, height=ancho_img * hh / w), Paragraph(md(b[2]), est["cap"])]))
    doc.build(h)
    return salida


if __name__ == "__main__":
    from app import VALIDACION, spline_principal, guardar_huella
    print("PDF generado:", generar(spline_principal(), VALIDACION))
    guardar_huella()

"""Datos que debes completar antes de presentar. Solo edita este archivo."""

ESTUDIANTE = "Nombre del estudiante"          # <- escribe tu nombre completo
CURSO = "Métodos Numéricos"                    # <- materia o curso
DOCENTE = ""                                   # <- opcional
FECHA = "Noviembre de 2026"
TITULO_TRABAJO = "Reconstrucción digital del Monolito Fraile mediante splines cúbicos"

# Pega aquí el enlace público o no listado del video (el único entregable del desafío).
# Ejemplo: "https://youtu.be/XXXXXXXXXXX". Si lo dejas vacío, la sección Video usa solo el archivo local.
YOUTUBE_URL = ""

# Ficha de la pieza. Revisa estos datos con lo que viste en el museo y corrígelos si hace falta.
FICHA = {
    "Pieza": "Monolito Fraile",
    "Cultura": "Tiwanaku (periodo clásico, aprox. 500–1100 d. C.)",
    "Lugar": "Tiwanaku, departamento de La Paz, Bolivia",
    "Tipo": "Escultura lítica antropomorfa",
    "Fuente de los datos": "Fotografía frontal de la pieza, digitalizada punto por punto",
}

# Servidor local
HOST = "127.0.0.1"
PORT = 5000

"""Fraile Digital: presentación web del desafío final de splines cúbicos.

Ejecutar:  python app.py   y abrir  http://127.0.0.1:5000
"""
from __future__ import annotations

import csv
from functools import lru_cache
from pathlib import Path

from flask import Flask, abort, jsonify, render_template, send_from_directory

import config
import informe_contenido
from splines import ALTO_IMAGEN, SplineParametrico, leer_puntos

BASE = Path(__file__).resolve().parent
DATOS = BASE / "data"
CODIGO = BASE / "codigo"

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["TEMPLATES_AUTO_RELOAD"] = True

# ----------------------------------------------------------------------------- datos

# Parte superior izquierda de la cabeza que se completa (coordenadas de imagen, y hacia abajo).
PUNTOS_AZUL = [(470, 62), (440, 68), (388, 80), (361, 107), (343, 153), (340, 214), (343, 259), (347, 285)]

# Recorte de la cabeza usado en las imágenes cabeza_*.png (x0, y0, ancho, alto, en px de la imagen completa)
RECORTE = {"x": 280, "y": 20, "w": 460, "h": 520}

VALIDACION = {
    "zona": "P10 a P12",
    "plan_a": {"medio": 13.0, "maximo": 26.2},
    "plan_b": {"medio": 18.5, "maximo": 49.2},
    "restauracion": {"medio": 0.52, "maximo": 1.96},
}

CAPITULOS_VIDEO = [  # (segundos, título corto)
    (0, "Pieza original"), (5, "Zona seleccionada"), (11, "Puntos de control"), (19, "Primeros segmentos"),
    (27, "Spline completo"), (35, "Validación: Plan B"), (47, "Validación: Plan A"), (59, "Resultado final"),
]

CODIGOS = {
    "digitalizar.py": "Carga el contorno, ubica los puntos y arma la escena de contexto.",
    "spline_propio.py": "Spline natural desde cero y verificación de C0, C1 y C2.",
    "reconstruccion.py": "Valida el método: pierde 3 puntos y compara Plan A y Plan B.",
    "animacion.py": "Restaura la zona azul y genera el video fotograma a fotograma.",
}

DESCARGAS = {
    "informe": ("informe", "Informe_Reconstruccion_Monolito_Fraile.pdf"),
    "puntos": ("data", "puntos.csv"),
    "coeficientes": ("data", "coeficientes.csv"),
}


@lru_cache(maxsize=1)
def spline_principal() -> SplineParametrico:
    return SplineParametrico(leer_puntos(DATOS / "puntos.csv"))


def puntos_imagen():
    """Puntos con y hacia abajo (coordenadas de pantalla) para dibujar sobre la imagen."""
    return [(x, ALTO_IMAGEN - y) for x, y in spline_principal().puntos]


# ----------------------------------------------------------------------------- páginas

@app.route("/")
def inicio():
    s = spline_principal()
    cont = s.continuidad()
    return render_template(
        "index.html",
        cfg=config,
        n_puntos=len(s.puntos),
        n_tramos=s.n,
        puntos=s.puntos,
        coef_x=s.cx, coef_y=s.cy, t=s.t,
        cont=cont,
        datos=payload_spline(),
        informe=informe_contenido.construir(s, config, VALIDACION, cont),
        puntos_azul=PUNTOS_AZUL,
        validacion=VALIDACION,
        capitulos=CAPITULOS_VIDEO,
        codigos=CODIGOS,
        recorte=RECORTE,
        alto=ALTO_IMAGEN,
        youtube_id=_youtube_id(config.YOUTUBE_URL),
    )


def _youtube_id(url: str) -> str:
    import re
    m = re.search(r"(?:youtu\.be/|v=|embed/|shorts/)([A-Za-z0-9_-]{11})", url or "")
    return m.group(1) if m else ""


# ----------------------------------------------------------------------------- API

def payload_spline() -> dict:
    s = spline_principal()
    cont = s.continuidad()
    return {
        "alto": ALTO_IMAGEN,
        "recorte": RECORTE,
        "puntos": [{"i": i + 1, "x": x, "y": y, "xi": x, "yi": ALTO_IMAGEN - y} for i, (x, y) in enumerate(s.puntos)],
        "t": s.t,
        "coef": {
            "x": {"a": s.cx[0], "b": s.cx[1], "c": s.cx[2], "d": s.cx[3]},
            "y": {"a": s.cy[0], "b": s.cy[1], "c": s.cy[2], "d": s.cy[3]},
        },
        "continuidad": {k: cont[k] for k in ("C0", "C1", "C2")},
        "pasa_por_puntos": s.pasa_por_los_puntos(),
        "tramos": [[[round(x, 4), round(y, 4)] for x, y in tr] for tr in s.muestras(40)],
        "azul": [{"i": i + 1, "x": x, "y": y} for i, (x, y) in enumerate(PUNTOS_AZUL)],
        "validacion": VALIDACION,
        "capitulos": [{"t": t, "titulo": n} for t, n in CAPITULOS_VIDEO],
    }


@app.route("/api/spline")
def api_spline():
    return jsonify(payload_spline())


@app.route("/api/restauracion")
def api_restauracion():
    return jsonify({
        "recorte": RECORTE,
        "puntos_azul": [{"i": i + 1, "x": x, "y": y} for i, (x, y) in enumerate(PUNTOS_AZUL)],
        "validacion": VALIDACION,
    })


@app.route("/api/codigo/<nombre>")
def api_codigo(nombre):
    if nombre not in CODIGOS:
        abort(404)
    texto = (CODIGO / nombre).read_text(encoding="utf-8")
    return jsonify({"nombre": nombre, "descripcion": CODIGOS[nombre], "lineas": texto.count("\n") + 1, "texto": texto})


@app.route("/descargas/<clave>")
def descargas(clave):
    if clave in DESCARGAS:
        carpeta, archivo = DESCARGAS[clave]
        ruta = (BASE / "static" / "informe") if carpeta == "informe" else DATOS
        return send_from_directory(ruta, archivo, as_attachment=True)
    if clave in CODIGOS:
        return send_from_directory(CODIGO, clave, as_attachment=True)
    abort(404)


@app.route("/salud")
def salud():
    return jsonify({"estado": "ok"})


@app.errorhandler(404)
def no_encontrado(_e):
    return render_template("404.html", cfg=config, datos=payload_spline()), 404


def crear_coeficientes_csv():
    """Genera data/coeficientes.csv (para descargar) a partir del spline calculado aquí."""
    s = spline_principal()
    with open(DATOS / "coeficientes.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["tramo", "t_ini", "t_fin", "ax", "bx", "cx", "dx", "ay", "by", "cy", "dy"])
        for i in range(s.n):
            w.writerow([i + 1, f"{s.t[i]:.10g}", f"{s.t[i+1]:.10g}"]
                       + [f"{s.cx[k][i]:.10g}" for k in range(4)] + [f"{s.cy[k][i]:.10g}" for k in range(4)])


crear_coeficientes_csv()


def _huella() -> str:
    import hashlib
    datos = "|".join(str(getattr(config, k, "")) for k in ("ESTUDIANTE", "CURSO", "DOCENTE", "FECHA", "TITULO_TRABAJO", "YOUTUBE_URL"))
    return hashlib.sha1(datos.encode("utf-8")).hexdigest()


def guardar_huella():
    (BASE / "static" / "informe" / ".huella").write_text(_huella(), encoding="utf-8")


def asegurar_informe():
    """Si cambiaste tus datos en config.py, vuelve a generar el PDF (necesita reportlab)."""
    pdf = BASE / "static" / "informe" / "Informe_Reconstruccion_Monolito_Fraile.pdf"
    huella = BASE / "static" / "informe" / ".huella"
    actual = huella.read_text(encoding="utf-8").strip() if huella.exists() else ""
    if pdf.exists() and actual == _huella():
        return
    try:
        import generar_informe
        generar_informe.generar(spline_principal(), VALIDACION)
        guardar_huella()
        print("Informe PDF actualizado con tus datos.")
    except ImportError:
        print("Aviso: instala reportlab (pip install reportlab) para regenerar el PDF con tus datos.")
    except Exception as e:  # el resto de la app funciona igual
        print("Aviso: no se pudo generar el PDF:", e)


asegurar_informe()

if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT, debug=False)

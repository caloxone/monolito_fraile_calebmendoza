# Fraile Digital

Presentación web (Flask) del desafío final: **reconstrucción digital del Monolito Fraile con splines cúbicos**.
Tiene diez secciones: Inicio, Pieza, Puntos, Spline, Pasos, Video, Informe, Código, Guion y Cierre.

## Cómo abrirla

**Windows:** doble clic en `iniciar.bat`.
**Mac o Linux:** en la terminal, `./iniciar.sh`.

La primera vez prepara un entorno e instala Flask y reportlab (necesita internet una sola vez). Después abre
`http://127.0.0.1:5000` en tu navegador. Para cerrar la app, `Ctrl + C`.

A mano: `pip install -r requirements.txt` y luego `python app.py`.

## Lo primero que debes hacer

Abre **`config.py`** y completa:

- `ESTUDIANTE`, `CURSO`, `DOCENTE`, `FECHA`
- `YOUTUBE_URL`: el enlace de tu video (aparece como pestaña en la sección Video y en el registro del Cierre)
- `FICHA`: revisa los datos de la pieza con lo que viste en el museo

Al guardar y reiniciar la app, el informe en PDF se vuelve a generar con tus datos (necesita reportlab).

## Qué hay en cada sección

| Sección | Qué muestra |
|---|---|
| Inicio | Portada con el spline trazándose, ruta del desafío y lista de los 11 elementos obligatorios |
| Pieza | La pieza completa, la zona elegida y lo que falta, con su justificación |
| Puntos | Los 15 puntos sobre la imagen, tabla de coordenadas y descarga del CSV |
| Spline | Fórmulas, continuidad C⁰ C¹ C², laboratorio interactivo (arrastra los puntos) y tabla de coeficientes |
| Pasos | Los 7 pasos con el fotograma del video, comparador antes/después y validación Plan A / Plan B |
| Video | La animación (1280×720) con capítulos; pestaña de YouTube si pones el enlace |
| Informe | Visor de lectura (con índice y tamaño de letra) y visor de PDF, con descarga |
| Código | Los cuatro programas, con fragmentos clave explicados |
| Guion | Los seis momentos de los 3 minutos, con cronómetro de ensayo |
| Cierre | Conclusión, rúbrica y registro del estudiante para copiar |

Atajos: `←` `→` cambian de sección. En Video: `Mayús + ←/→` avanza 5 s y `F` pantalla completa.

## Estructura

```
app.py               servidor Flask y datos
config.py            tus datos (edítalo)
splines.py           spline cúbico paramétrico en Python puro (sin NumPy)
informe_contenido.py texto del informe (sirve a la web y al PDF)
generar_informe.py   genera el PDF
templates/ static/   páginas, estilos, scripts, imágenes, fuentes, video e informe
codigo/              los programas del trabajo (ver LEEME_codigo.txt)
data/                puntos.csv y coeficientes
tests/               pruebas: python -m unittest discover -s tests -v
```

## Verificaciones incluidas

- El spline de `splines.py` coincide con tu `coeficientes.csv` (diferencia ≈ 5·10⁻¹⁵).
- La sección Spline compara el cálculo del navegador (JavaScript) con el del servidor (Python): diferencia 0.
- `python -m unittest discover -s tests -v` comprueba continuidad, rutas y archivos.

## Tipografías

Titulares en **Lora cursiva** (escritura), texto en **Lora** y datos en **LM Mono** (máquina de escribir). Están incluidas
en `static/fonts/`, así que la app se ve igual sin internet. Para cambiarlas, edita `--texto` y `--maquina` al inicio de `static/css/app.css`.

## Si algo no funciona

- *No abre en el navegador:* entra a mano a `http://127.0.0.1:5000`.
- *El puerto 5000 está ocupado:* cambia `PORT` en `config.py`.
- *No se ve el PDF dentro de la página:* usa el botón «Descargar PDF».

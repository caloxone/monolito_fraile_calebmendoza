"""Pruebas rápidas. Ejecutar desde la carpeta de la app:  python -m unittest discover -s tests -v"""
import csv
import sys
import unittest
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

import app as web  # noqa: E402
from splines import SplineParametrico, leer_puntos  # noqa: E402


class PruebasSpline(unittest.TestCase):
    def setUp(self):
        self.s = SplineParametrico(leer_puntos(RAIZ / "data" / "puntos.csv"))

    def test_quince_puntos_catorce_tramos(self):
        self.assertEqual(len(self.s.puntos), 15)
        self.assertEqual(self.s.n, 14)

    def test_pasa_por_los_puntos(self):
        self.assertLess(self.s.pasa_por_los_puntos(), 1e-9)

    def test_continuidad_c0_c1_c2(self):
        c = self.s.continuidad()
        self.assertLess(c["C0"], 1e-9)
        self.assertLess(c["C1"], 1e-9)
        self.assertLess(c["C2"], 1e-9)

    def test_coincide_con_coeficientes_de_referencia(self):
        filas = list(csv.reader(open(RAIZ / "data" / "coeficientes_referencia.csv")))[1:]
        peor = 0.0
        for i, fila in enumerate(filas):
            v = [float(z) for z in fila][3:]
            mio = [self.s.cx[k][i] for k in range(4)] + [self.s.cy[k][i] for k in range(4)]
            peor = max(peor, max(abs(a - b) for a, b in zip(v, mio)))
        self.assertLess(peor, 1e-9)


class PruebasWeb(unittest.TestCase):
    def setUp(self):
        self.c = web.app.test_client()

    def test_rutas_ok(self):
        for ruta in ["/", "/salud", "/api/spline", "/api/restauracion", "/descargas/informe", "/descargas/puntos",
                     "/descargas/coeficientes", "/static/video/animacion_monolito.mp4", "/static/css/app.css", "/static/js/app.js"]:
            self.assertEqual(self.c.get(ruta).status_code, 200, ruta)
        for nombre in web.CODIGOS:
            self.assertEqual(self.c.get(f"/api/codigo/{nombre}").status_code, 200, nombre)
            self.assertEqual(self.c.get(f"/descargas/{nombre}").status_code, 200, nombre)

    def test_rutas_inexistentes_y_seguridad(self):
        self.assertEqual(self.c.get("/nada").status_code, 404)
        self.assertEqual(self.c.get("/api/codigo/../app.py").status_code, 404)
        self.assertEqual(self.c.get("/api/codigo/config.py").status_code, 404)
        self.assertEqual(self.c.get("/descargas/config.py").status_code, 404)

    def test_video_admite_rangos(self):
        r = self.c.get("/static/video/animacion_monolito.mp4", headers={"Range": "bytes=0-99"})
        self.assertEqual(r.status_code, 206)

    def test_archivos_referenciados_existen(self):
        import re
        html = self.c.get("/").get_data(as_text=True)
        for ruta in set(re.findall(r'(?:src|href)="(/static/[^"#?]+)', html)):
            self.assertEqual(self.c.get(ruta).status_code, 200, ruta)


if __name__ == "__main__":
    unittest.main()

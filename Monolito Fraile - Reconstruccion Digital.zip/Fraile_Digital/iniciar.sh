#!/usr/bin/env bash
# Fraile Digital: prepara el entorno la primera vez y abre la app.
cd "$(dirname "$0")" || exit 1
command -v python3 >/dev/null 2>&1 || { echo "No se encontro python3. Instalalo primero."; exit 1; }
if [ ! -d ".venv" ]; then
  echo "Preparando la app por primera vez..."
  python3 -m venv .venv && . .venv/bin/activate && pip install --upgrade pip >/dev/null && pip install -r requirements.txt
else
  . .venv/bin/activate
fi
echo
echo "Abre http://127.0.0.1:5000 en tu navegador. Para cerrar la app presiona Ctrl+C."
(command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:5000 >/dev/null 2>&1) || (command -v open >/dev/null && open http://127.0.0.1:5000) || true
python app.py

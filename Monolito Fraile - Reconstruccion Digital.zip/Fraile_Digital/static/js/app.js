/* Fraile Digital · comportamiento de la app. Sin dependencias. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var NS = "http://www.w3.org/2000/svg";
  var DATA = JSON.parse($("#datos").textContent);
  var REDUCIDO = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var R = DATA.recorte, ALTO = DATA.alto;

  function el(tag, attrs, padre) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    if (padre) padre.appendChild(e);
    return e;
  }
  function color(i, n) { return "hsl(" + Math.round(165 + (i / Math.max(n - 1, 1)) * 330) % 360 + " 85% 58%)"; }
  function guardar(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* sin almacenamiento */ } }
  function leer(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function copiar(texto, boton) {
    var ok = function () { if (!boton) return; var t = boton.innerHTML; boton.textContent = "Copiado"; setTimeout(function () { boton.innerHTML = t; }, 1400); };
    if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(texto).then(ok, function () { viejo(); }); } else { viejo(); }
    function viejo() {
      var a = document.createElement("textarea"); a.value = texto; a.style.position = "fixed"; a.style.opacity = "0"; document.body.appendChild(a); a.select();
      try { document.execCommand("copy"); ok(); } catch (e) { /* nada */ } document.body.removeChild(a);
    }
  }
  var f = function (v, d) { return Number(v).toFixed(d); };

  /* ------------------------------------------------------------------ spline (mismo algoritmo que splines.py) */
  function parametro(P) {
    var t = [0];
    for (var i = 1; i < P.length; i++) t.push(t[i - 1] + Math.sqrt(Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1])));
    return t;
  }
  function coefs(t, y) {
    var n = t.length - 1, h = [], i;
    for (i = 0; i < n; i++) h.push(t[i + 1] - t[i]);
    var c = new Array(n + 1).fill(0);
    if (n >= 2) {
      var m = n - 1, a = [], b = [], cc = [], r = [];
      for (i = 1; i < n; i++) {
        a.push(h[i - 1]); b.push(2 * (h[i - 1] + h[i])); cc.push(h[i]);
        r.push(3 * ((y[i + 1] - y[i]) / h[i] - (y[i] - y[i - 1]) / h[i - 1]));
      }
      for (i = 1; i < m; i++) { var w = a[i] / b[i - 1]; b[i] -= w * cc[i - 1]; r[i] -= w * r[i - 1]; }
      var x = new Array(m).fill(0); x[m - 1] = r[m - 1] / b[m - 1];
      for (i = m - 2; i >= 0; i--) x[i] = (r[i] - cc[i] * x[i + 1]) / b[i];
      for (i = 0; i < m; i++) c[i + 1] = x[i];
    }
    var A = [], B = [], C = [], D = [];
    for (i = 0; i < n; i++) {
      A.push(y[i]); C.push(c[i]);
      B.push((y[i + 1] - y[i]) / h[i] - h[i] * (2 * c[i] + c[i + 1]) / 3);
      D.push((c[i + 1] - c[i]) / (3 * h[i]));
    }
    return { a: A, b: B, c: C, d: D };
  }
  function Spline(P) {          // P: [[x, y], ...] con y hacia arriba (convención del CSV)
    this.P = P; this.t = parametro(P); this.n = P.length - 1;
    this.cx = coefs(this.t, P.map(function (p) { return p[0]; }));
    this.cy = coefs(this.t, P.map(function (p) { return p[1]; }));
  }
  Spline.prototype.ev = function (i, s, orden) {
    var u = s - this.t[i], q = function (c) {
      if (orden === 0) return c.a[i] + c.b[i] * u + c.c[i] * u * u + c.d[i] * u * u * u;
      if (orden === 1) return c.b[i] + 2 * c.c[i] * u + 3 * c.d[i] * u * u;
      return 2 * c.c[i] + 6 * c.d[i] * u;
    };
    return [q(this.cx), q(this.cy)];
  };
  Spline.prototype.muestras = function (i, k) {
    var out = [], h = this.t[i + 1] - this.t[i];
    for (var j = 0; j <= k; j++) out.push(this.ev(i, this.t[i] + h * j / k, 0));
    return out;
  };
  Spline.prototype.continuidad = function () {
    var e = [0, 0, 0];
    for (var i = 1; i < this.n; i++) for (var o = 0; o < 3; o++) {
      var l = this.ev(i - 1, this.t[i], o), r = this.ev(i, this.t[i], o);
      e[o] = Math.max(e[o], Math.hypot(l[0] - r[0], l[1] - r[1]));
    }
    return e;
  };
  // pantalla (recorte) <-> matemática (CSV, y hacia arriba)
  function aPantalla(p) { return [p[0] - R.x, ALTO - p[1] - R.y]; }
  function aMate(x, y) { return [x + R.x, ALTO - (y + R.y)]; }
  function trazo(pts) { return pts.map(function (p, i) { var s = aPantalla(p); return (i ? "L" : "M") + s[0].toFixed(2) + " " + s[1].toFixed(2); }).join(" "); }

  var PUNTOS0 = DATA.puntos.map(function (p) { return [p.x, p.y]; });

  /* ------------------------------------------------------------------ navegación */
  var VISTAS = $$(".vista").map(function (v) { return v.dataset.vista; });
  var visitadas = {};
  try { visitadas = JSON.parse(leer("fraile-visitadas") || "{}"); } catch (e) { visitadas = {}; }
  var actual = null;

  function mostrar(id, sinFoco) {
    if (VISTAS.indexOf(id) < 0) id = "inicio";
    actual = id;
    $$(".vista").forEach(function (v) { v.classList.toggle("activa", v.dataset.vista === id); });
    $$(".nav-item").forEach(function (a) {
      if (a.dataset.vista === id) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    var v = $("#v-" + id); document.title = v.dataset.titulo + " · Fraile Digital";
    $("#migas").textContent = "/ " + v.dataset.titulo.toLowerCase();
    document.documentElement.style.setProperty("--acento", getComputedStyle(v).getPropertyValue("--acento"));
    visitadas[id] = 1; guardar("fraile-visitadas", JSON.stringify(visitadas)); progreso();
    window.scrollTo(0, 0);
    if (!sinFoco) $("#contenido").focus({ preventScroll: true });
    var ev = new CustomEvent("vista", { detail: id }); document.dispatchEvent(ev);
  }
  function progreso() {
    var n = 0;
    $$(".nav-item").forEach(function (a) { var s = !!visitadas[a.dataset.vista]; a.classList.toggle("es-visto", s); if (s) n++; });
    $("#avance-texto").textContent = n + " de " + VISTAS.length;
    $("#avance-barra").style.width = (n / VISTAS.length * 100) + "%";
  }
  function desdeHash() {
    var m = location.hash.match(/^#\/([a-z]+)/);
    mostrar(m ? m[1] : "inicio", true);
  }
  window.addEventListener("hashchange", desdeHash);
  document.addEventListener("keydown", function (e) {
    var t = e.target, tag = (t && t.tagName) || "";
    if (/INPUT|TEXTAREA|SELECT|VIDEO/.test(tag) || (t && t.getAttribute && t.getAttribute("role") === "tab") || e.altKey || e.ctrlKey || e.metaKey) return;
    var i = VISTAS.indexOf(actual);
    if (e.key === "ArrowRight" && i < VISTAS.length - 1) { location.hash = "#/" + VISTAS[i + 1]; }
    if (e.key === "ArrowLeft" && i > 0) { location.hash = "#/" + VISTAS[i - 1]; }
  });
  $("#btn-pantalla").addEventListener("click", function () {
    if (!document.fullscreenElement) { (document.documentElement.requestFullscreen || function () {}).call(document.documentElement); }
    else { document.exitFullscreen(); }
  });

  /* ------------------------------------------------------------------ inicio: trazo del spline */
  var hero = { timer: null };
  function heroTrazar() {
    var capa = $("#hero-curva"), pts = $("#hero-puntos"), estado = $("#hero-estado");
    capa.innerHTML = ""; pts.innerHTML = "";
    cancelAnimationFrame(hero.timer);
    var tramos = DATA.tramos, n = tramos.length, paths = [];
    DATA.puntos.forEach(function (p, i) {
      var s = aPantalla([p.x, p.y]);
      var g = el("g", { opacity: REDUCIDO ? 1 : 0 }, pts);
      el("circle", { cx: s[0], cy: s[1], r: 5.5, fill: "#f7b92b", stroke: "#170f1f", "stroke-width": 2 }, g);
      g.dataset.i = i;
    });
    tramos.forEach(function (tr, i) {
      var p = el("path", { d: trazo(tr), stroke: color(i, n), "stroke-width": 4 }, capa);
      var L = p.getTotalLength(); p.style.strokeDasharray = L; p.style.strokeDashoffset = REDUCIDO ? 0 : L; paths.push([p, L]);
    });
    if (REDUCIDO) { estado.textContent = n + " tramos unidos · C0, C1 y C2"; return; }
    var inicio = null, aparicion = 1100, porTramo = 420;
    function paso(ts) {
      if (inicio === null) inicio = ts;
      var t = ts - inicio;
      $$("#hero-puntos g").forEach(function (g, i) { var k = Math.min(Math.max((t - i * 55) / 250, 0), 1); g.setAttribute("opacity", k); });
      var tt = t - aparicion, hecho = true;
      paths.forEach(function (pl, i) { var k = Math.min(Math.max((tt - i * porTramo) / porTramo, 0), 1); pl[0].style.strokeDashoffset = pl[1] * (1 - k); if (k < 1) hecho = false; });
      if (t < aparicion) estado.textContent = "Puntos de control: " + Math.min(DATA.puntos.length, Math.floor(t / 55) + 1) + " / " + DATA.puntos.length;
      else if (!hecho) estado.textContent = "Trazando tramo " + Math.min(n, Math.floor(tt / porTramo) + 1) + " de " + n;
      else estado.textContent = n + " tramos unidos · C0, C1 y C2";
      if (!hecho || t < aparicion) hero.timer = requestAnimationFrame(paso);
    }
    estado.textContent = "Puntos de control…";
    hero.timer = requestAnimationFrame(paso);
  }
  var heroListo = false;
  document.addEventListener("vista", function (e) { if (e.detail === "inicio" && !heroListo) { heroListo = true; heroTrazar(); } });
  $("#hero-repetir").addEventListener("click", heroTrazar);
  $("#hero-alterna").addEventListener("click", function () {
    var on = this.getAttribute("aria-pressed") !== "true";
    this.setAttribute("aria-pressed", on); this.textContent = on ? "Ver original" : "Ver restaurada";
    $("#hero-restaurada").setAttribute("opacity", on ? 1 : 0);
  });

  /* ------------------------------------------------------------------ pieza */
  $("#pieza-alterna").addEventListener("click", function () {
    var on = this.getAttribute("aria-pressed") !== "true";
    this.setAttribute("aria-pressed", on); this.textContent = on ? "Ocultar lo que falta" : "Mostrar lo que falta";
    $("#pieza-azul").setAttribute("opacity", on ? 1 : 0);
  });

  /* ------------------------------------------------------------------ puntos */
  (function () {
    var capa = $("#puntos-capa"), lectura = $("#puntos-lectura"), curva = null, filas = $$("#tabla-puntos tbody tr");
    DATA.puntos.forEach(function (p, i) {
      var s = aPantalla([p.x, p.y]);
      var g = el("g", { "class": "pt", tabindex: 0, role: "img", "aria-label": "Punto " + p.i + " con x " + f(p.x, 1) + " e y " + f(p.y, 1) }, capa);
      var perdido = i >= 9 && i <= 11;
      el("circle", { cx: s[0], cy: s[1], r: 6, fill: perdido ? "#d3303d" : "#f7b92b", stroke: "#170f1f", "stroke-width": 2 }, g);
      var tx = el("text", { x: s[0] + 10, y: s[1] - 8 }, g); tx.textContent = "P" + p.i;
      g.addEventListener("mouseenter", function () { act(i); }); g.addEventListener("focus", function () { act(i); });
      g.addEventListener("mouseleave", function () { act(-1); }); g.addEventListener("blur", function () { act(-1); });
    });
    function act(i) {
      $$(".pt", capa).forEach(function (g, k) { g.classList.toggle("activo", k === i); });
      filas.forEach(function (r, k) { r.classList.toggle("activo", k === i); });
      lectura.textContent = i < 0 ? "Pasa el cursor por un punto o una fila" : "P" + (i + 1) + " = (" + f(DATA.puntos[i].x, 1) + ", " + f(DATA.puntos[i].y, 1) + ")";
    }
    filas.forEach(function (r, k) { r.addEventListener("mouseenter", function () { act(k); }); r.addEventListener("mouseleave", function () { act(-1); }); });
    $("#puntos-curva").addEventListener("click", function () {
      var on = this.getAttribute("aria-pressed") !== "true";
      this.setAttribute("aria-pressed", on); this.textContent = on ? "Ocultar spline" : "Mostrar spline";
      if (on && !curva) {
        curva = el("g", { fill: "none", "stroke-linecap": "round", "stroke-linejoin": "round" });
        DATA.tramos.forEach(function (tr, i) { el("path", { d: trazo(tr), stroke: color(i, DATA.tramos.length), "stroke-width": 3.5 }, curva); });
        capa.parentNode.insertBefore(curva, capa);
      }
      if (curva) curva.setAttribute("display", on ? "inline" : "none");
    });
    $("#copiar-csv").addEventListener("click", function () {
      copiar("x,y\n" + DATA.puntos.map(function (p) { return p.x + "," + p.y; }).join("\n"), this);
    });
  })();

  /* ------------------------------------------------------------------ laboratorio del spline */
  (function () {
    var svg = $("#lab-svg"), gCurva = $("#lab-curva"), gTang = $("#lab-tangentes"), gPts = $("#lab-puntos");
    var P = PUNTOS0.map(function (p) { return p.slice(); }), S = new Spline(P), sel = 0, vis = S.n, tang = false, trazando = null;
    var rango = $("#lab-tramos");

    function fmt(v, d) { return (v < 0 ? "−" : "+") + Math.abs(v).toFixed(d); }
    function poli() {
      var i = sel, t0 = S.t[i].toFixed(3);
      $("#lab-tramo-num").textContent = (i + 1) + " de " + S.n;
      $("#lab-poli").innerHTML =
        "<em>t ∈ [" + t0 + ", " + S.t[i + 1].toFixed(3) + "]</em>\n" +
        "X(t) = " + S.cx.a[i].toFixed(2) + " " + fmt(S.cx.b[i], 3) + "(t−" + t0 + ") " + fmt(S.cx.c[i], 4) + "(t−" + t0 + ")² " + fmt(S.cx.d[i], 5) + "(t−" + t0 + ")³\n" +
        "Y(t) = " + S.cy.a[i].toFixed(2) + " " + fmt(S.cy.b[i], 3) + "(t−" + t0 + ") " + fmt(S.cy.c[i], 4) + "(t−" + t0 + ")² " + fmt(S.cy.d[i], 5) + "(t−" + t0 + ")³";
    }
    function expo(v) { return v === 0 ? "0" : v.toExponential(1); }
    function dibuja() {
      gCurva.innerHTML = ""; gTang.innerHTML = "";
      for (var i = 0; i < Math.min(vis, S.n); i++) {
        var p = el("path", { d: trazo(S.muestras(i, 30)), stroke: color(i, S.n), "stroke-width": i === sel ? 6 : 3.5, "data-i": i, style: "cursor:pointer" }, gCurva);
        var hit = el("path", { d: trazo(S.muestras(i, 30)), stroke: "transparent", "stroke-width": 16, "data-i": i, style: "cursor:pointer" }, gCurva);
        hit.addEventListener("click", (function (k) { return function () { sel = k; dibuja(); poli(); }; })(i));
        void p;
      }
      if (tang) {
        for (var j = 0; j <= Math.min(vis, S.n); j++) {
          var k = Math.min(j, S.n - 1), s = j === S.n ? S.t[S.n] : S.t[j], d = S.ev(k, s, 1), m = Math.hypot(d[0], d[1]) || 1, q = S.P[j];
          var a = aPantalla([q[0] - d[0] / m * 22, q[1] - d[1] / m * 22]), b = aPantalla([q[0] + d[0] / m * 22, q[1] + d[1] / m * 22]);
          el("line", { x1: a[0], y1: a[1], x2: b[0], y2: b[1] }, gTang);
        }
      }
      var e = S.continuidad();
      $("#lab-c0").textContent = expo(e[0]); $("#lab-c1").textContent = expo(e[1]); $("#lab-c2").textContent = expo(e[2]);
      $("#lab-tramos-val").textContent = Math.min(vis, S.n) + " / " + S.n;
    }
    function puntos() {
      gPts.innerHTML = "";
      S.P.forEach(function (p, i) {
        var s = aPantalla(p), g = el("g", { "class": "pt", tabindex: 0, role: "slider", "aria-label": "Punto P" + (i + 1) + ", arrastra o usa las flechas" }, gPts);
        el("circle", { cx: s[0], cy: s[1], r: 7, fill: "#f7b92b", stroke: "#170f1f", "stroke-width": 2, style: "cursor:grab" }, g);
        var tx = el("text", { x: s[0] + 10, y: s[1] - 9 }, g); tx.textContent = "P" + (i + 1);
        g.addEventListener("pointerdown", function (ev) { ev.preventDefault(); g.setPointerCapture(ev.pointerId); g.dataset.arrastra = 1; g.classList.add("activo"); });
        g.addEventListener("pointermove", function (ev) {
          if (!g.dataset.arrastra) return;
          var pt = svg.createSVGPoint(); pt.x = ev.clientX; pt.y = ev.clientY;
          var l = pt.matrixTransform(svg.getScreenCTM().inverse());
          var x = Math.min(Math.max(l.x, 0), R.w), y = Math.min(Math.max(l.y, 0), R.h);
          P[i] = aMate(x, y); recalcula(false);
          var c = g.querySelector("circle"), t = g.querySelector("text");
          c.setAttribute("cx", x); c.setAttribute("cy", y); t.setAttribute("x", x + 10); t.setAttribute("y", y - 9);
        });
        var fin = function () { delete g.dataset.arrastra; g.classList.remove("activo"); };
        g.addEventListener("pointerup", fin); g.addEventListener("pointercancel", fin);
        g.addEventListener("keydown", function (ev) {
          var dx = { ArrowLeft: -3, ArrowRight: 3 }[ev.key] || 0, dy = { ArrowUp: 3, ArrowDown: -3 }[ev.key] || 0;
          if (!dx && !dy) return; ev.preventDefault(); ev.stopPropagation();
          P[i] = [P[i][0] + dx, P[i][1] + dy]; recalcula(true); gPts.children[i].focus();
        });
      });
    }
    function recalcula(redibujaPuntos) { S = new Spline(P); dibuja(); poli(); if (redibujaPuntos) puntos(); servidor(); }
    function servidor() {
      var igual = P.every(function (p, i) { return p[0] === PUNTOS0[i][0] && p[1] === PUNTOS0[i][1]; });
      var out = $("#lab-servidor");
      if (!igual) { out.textContent = "Puntos modificados: el cálculo ya no coincide con el original (es lo esperado)."; return; }
      var m = 0; ["a", "b", "c", "d"].forEach(function (k) { for (var i = 0; i < S.n; i++) { m = Math.max(m, Math.abs(S.cx[k][i] - DATA.coef.x[k][i]), Math.abs(S.cy[k][i] - DATA.coef.y[k][i])); } });
      out.innerHTML = "Navegador contra servidor (Python): diferencia máxima en los coeficientes = <span class='estado-ok'>" + (m === 0 ? "0" : m.toExponential(1)) + "</span>";
    }
    rango.addEventListener("input", function () { vis = +rango.value; if (sel >= vis && vis > 0) sel = vis - 1; dibuja(); });
    $("#lab-play").addEventListener("click", function () {
      if (trazando) { clearInterval(trazando); trazando = null; }
      if (REDUCIDO) { vis = S.n; rango.value = S.n; dibuja(); return; }
      vis = 0; rango.value = 0; dibuja();
      trazando = setInterval(function () { vis++; rango.value = vis; sel = vis - 1; dibuja(); poli(); if (vis >= S.n) { clearInterval(trazando); trazando = null; } }, 380);
    });
    $("#lab-tang").addEventListener("click", function () { tang = this.getAttribute("aria-pressed") !== "true"; this.setAttribute("aria-pressed", tang); dibuja(); });
    $("#lab-foto-btn").addEventListener("click", function () { var on = this.getAttribute("aria-pressed") !== "true"; this.setAttribute("aria-pressed", on); $("#lab-foto").setAttribute("opacity", on ? .55 : 0); });
    $("#lab-reset").addEventListener("click", function () { P = PUNTOS0.map(function (p) { return p.slice(); }); vis = S.n; rango.value = S.n; sel = 0; recalcula(true); });
    puntos(); dibuja(); poli(); servidor();
    document.addEventListener("vista", function (e) { if (e.detail === "spline") { servidor(); } });
  })();

  /* ------------------------------------------------------------------ pasos */
  (function () {
    var tabs = $$("#v-pasos .pasos__lista button"), paneles = $$("#v-pasos [role=tabpanel]");
    function ir(i) {
      i = Math.max(0, Math.min(paneles.length - 1, i));
      tabs.forEach(function (t, k) { t.setAttribute("aria-selected", k === i); });
      paneles.forEach(function (p, k) { p.hidden = k !== i; });
      tabs[i].scrollIntoView({ block: "nearest", inline: "nearest" });
      return i;
    }
    tabs.forEach(function (t, i) {
      t.addEventListener("click", function () { ir(i); });
      t.addEventListener("keydown", function (e) {
        var k = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[e.key];
        if (k) { e.preventDefault(); var j = ir(i + k); tabs[j].focus(); }
      });
    });
    $$("[data-ir]").forEach(function (b) {
      b.addEventListener("click", function () { var i = paneles.findIndex(function (p) { return !p.hidden; }); ir(i + (+b.dataset.ir)); window.scrollTo({ top: $("#v-pasos").offsetTop, behavior: "auto" }); });
    });
    $$(".miniaturas").forEach(function (m) {
      var cont = m.closest("[role=tabpanel]"), img = $(".paso-img", cont), pie = $(".paso-pie", cont);
      $$("button", m).forEach(function (b) {
        b.addEventListener("click", function () {
          $$("button", m).forEach(function (x) { x.setAttribute("aria-pressed", x === b); });
          img.src = b.dataset.src; img.alt = b.dataset.pie; pie.textContent = b.dataset.pie;
        });
      });
    });
    $$("[data-video]").forEach(function (b) { b.addEventListener("click", function () { saltoVideo = +b.dataset.video; location.hash = "#/video"; }); });

    var rango = $("#comparar-rango"), sup = $("#comparar-sup"), lin = $("#comparar-linea"), asa = $("#comparar-asa");
    function pos() { var v = +rango.value; sup.style.clipPath = "inset(0 " + (100 - v) + "% 0 0)"; lin.style.left = v + "%"; asa.style.left = v + "%"; }
    rango.addEventListener("input", pos); pos();
  })();

  /* ------------------------------------------------------------------ video */
  var saltoVideo = null;
  (function () {
    var v = $("#video"), caps = $$("#capitulos button");
    function marca() {
      var t = v.currentTime, k = 0;
      caps.forEach(function (b, i) { if (t >= +b.dataset.t - 0.05) k = i; });
      caps.forEach(function (b, i) { if (i === k && (v.currentTime > 0 || !v.paused)) b.setAttribute("aria-current", "true"); else b.removeAttribute("aria-current"); });
    }
    v.addEventListener("timeupdate", marca);
    caps.forEach(function (b) { b.addEventListener("click", function () { v.currentTime = +b.dataset.t; v.play().catch(function () {}); }); });
    function fuente(n) {
      $$("[data-fuente]").forEach(function (t) { t.setAttribute("aria-selected", t.dataset.fuente === n); });
      var pl = $("#panel-local"), py = $("#panel-youtube"), yt = $("#yt");
      if (pl) pl.hidden = n !== "local"; if (py) py.hidden = n !== "youtube";
      if (n === "youtube" && yt && !yt.src) yt.src = yt.dataset.src; if (n !== "youtube") v.pause();
    }
    $$("[data-fuente]").forEach(function (t) { t.addEventListener("click", function () { fuente(t.dataset.fuente); }); });
    document.addEventListener("vista", function (e) {
      if (e.detail !== "video") { v.pause(); return; }
      if (saltoVideo !== null) { var s = saltoVideo; saltoVideo = null; fuente("local"); v.currentTime = s; v.play().catch(function () {}); }
      $("#video-aviso").hidden = false;
    });
    document.addEventListener("keydown", function (e) {
      if (actual !== "video" || /INPUT|TEXTAREA|SELECT|BUTTON/.test(e.target.tagName) && e.target !== v) return;
      if (e.key === " " && e.target === document.body) { e.preventDefault(); v.paused ? v.play() : v.pause(); }
      if (e.key === "f" || e.key === "F") { if (v.requestFullscreen) v.requestFullscreen(); }
      if (e.key === "ArrowRight" && e.shiftKey) v.currentTime += 5;
      if (e.key === "ArrowLeft" && e.shiftKey) v.currentTime -= 5;
    });
  })();

  /* ------------------------------------------------------------------ informe */
  (function () {
    var lectura = $("#informe-lectura"), pdf = $("#informe-pdf"), marco = $("#pdf-marco"), hoja = $("#hoja"), zoom = 1;
    function modo(m) {
      $$("[data-modo]").forEach(function (b) { b.setAttribute("aria-selected", b.dataset.modo === m); });
      lectura.hidden = m !== "lectura"; pdf.hidden = m !== "pdf"; $("#inf-zoom").style.visibility = m === "lectura" ? "visible" : "hidden";
      if (m === "pdf" && !marco.getAttribute("src")) marco.setAttribute("src", marco.dataset.src);
    }
    $$("[data-modo]").forEach(function (b) { b.addEventListener("click", function () { modo(b.dataset.modo); }); });
    function z(d) { zoom = Math.min(1.5, Math.max(.8, +(zoom + d).toFixed(2))); hoja.style.setProperty("--ts", zoom); }
    $("#inf-mas").addEventListener("click", function () { z(.1); }); $("#inf-menos").addEventListener("click", function () { z(-.1); });
    $("#inf-imprimir").addEventListener("click", function () { modo("lectura"); window.print(); });
    var enlaces = $$("#informe-indice a");
    enlaces.forEach(function (a) {
      a.addEventListener("click", function (e) {
        e.preventDefault(); modo("lectura");
        var d = document.getElementById(a.dataset.ancla); lectura.scrollTo({ top: d.offsetTop - hoja.offsetTop - 10, behavior: REDUCIDO ? "auto" : "smooth" });
      });
    });
    lectura.addEventListener("scroll", function () {
      var y = lectura.scrollTop + hoja.offsetTop + 40, k = 0;
      enlaces.forEach(function (a, i) { if (document.getElementById(a.dataset.ancla).offsetTop <= y) k = i; });
      enlaces.forEach(function (a, i) { a.classList.toggle("activo", i === k); });
    });
    if (enlaces[0]) enlaces[0].classList.add("activo");
  })();

  /* ------------------------------------------------------------------ código */
  (function () {
    var KW = /\b(import|from|as|def|return|for|in|if|else|elif|while|with|class|lambda|not|and|or|True|False|None|try|except|raise|pass|break|continue|print)\b/;
    function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    function linea(s) {
      var out = "", i = 0, m;
      while (i < s.length) {
        var c = s[i], rest = s.slice(i);
        if (c === "#") { out += "<span class='tk-c'>" + esc(rest) + "</span>"; break; }
        if ((m = /^(f?)("""|'''|"[^"\\]*(?:\\.[^"\\]*)*"|'[^'\\]*(?:\\.[^'\\]*)*')/.exec(rest))) { out += "<span class='tk-s'>" + esc(m[0]) + "</span>"; i += m[0].length; continue; }
        if ((m = /^[A-Za-z_]\w*/.exec(rest))) {
          var w = m[0], sig = rest.slice(w.length);
          if (KW.test(w) && new RegExp("^" + KW.source + "$").test(w)) out += "<span class='tk-k'>" + w + "</span>";
          else if (/^\s*\(/.test(sig)) out += "<span class='tk-f'>" + w + "</span>"; else out += w;
          i += w.length; continue;
        }
        if ((m = /^\d[\d_.]*(?:e[+-]?\d+)?/i.exec(rest))) { out += "<span class='tk-n'>" + m[0] + "</span>"; i += m[0].length; continue; }
        out += esc(c); i++;
      }
      return out;
    }
    function pinta(texto) { return texto.replace(/\n$/, "").split("\n").map(function (l) { return "<span class='l'>" + (linea(l) || " ") + "</span>"; }).join(""); }
    $$("pre[data-lang=py]").forEach(function (p) { p.innerHTML = pinta(p.textContent); p.style.counterReset = "none"; });

    var cache = {}, actualArchivo = null, pre = $("#codigo-pre"), texto = "";
    function cargar(nombre) {
      actualArchivo = nombre;
      $$("#codigo-tabs button").forEach(function (b) { b.setAttribute("aria-selected", b.dataset.archivo === nombre); });
      $("#codigo-nombre").textContent = nombre; $("#codigo-bajar").setAttribute("href", "/descargas/" + nombre);
      if (cache[nombre]) return mostrarCodigo(cache[nombre]);
      pre.textContent = "Cargando…";
      fetch("/api/codigo/" + nombre).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function (j) { cache[nombre] = j; if (actualArchivo === nombre) mostrarCodigo(j); })
        .catch(function () { pre.textContent = "No se pudo cargar el archivo. Descárgalo con el botón de arriba."; });
    }
    function mostrarCodigo(j) { texto = j.texto; pre.innerHTML = pinta(j.texto); $("#codigo-desc").textContent = j.descripcion; $("#codigo-lineas").textContent = j.lineas + " líneas"; pre.scrollTop = 0; }
    $$("#codigo-tabs button").forEach(function (b) { b.addEventListener("click", function () { cargar(b.dataset.archivo); }); });
    $("#codigo-copiar").addEventListener("click", function () { copiar(texto, this); });
    var primero = $("#codigo-tabs button");
    document.addEventListener("vista", function (e) { if (e.detail === "codigo" && !texto && primero) cargar(primero.dataset.archivo); });
  })();

  /* ------------------------------------------------------------------ guion */
  (function () {
    var seg = 0, id = null, reloj = $("#reloj"), btn = $("#reloj-play"), cursor = $("#cursor-tiempo"), tramos = $$("#linea-tiempo .tramo"), partes = $$(".parte"), TOTAL = 180;
    function mmss(s) { return Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2); }
    function pinta() {
      reloj.textContent = mmss(seg);
      cursor.style.left = Math.min(seg / TOTAL * 100, 100) + "%";
      var k = -1; tramos.forEach(function (t, i) { if (seg >= +t.dataset.ini && seg < +t.dataset.fin) k = i; });
      tramos.forEach(function (t, i) { t.classList.toggle("activo", i === k || seg === 0); });
      partes.forEach(function (p, i) { p.classList.toggle("activa", i === k); });
      var msg = seg === 0 ? "Duración recomendada: 2 a 3 minutos." : seg < 120 ? "Por debajo de 2:00." : seg <= TOTAL ? "Dentro del tiempo (2:00 a 3:00)." : "Te pasaste de 3:00.";
      $("#reloj-parte").textContent = msg;
      reloj.style.color = seg > TOTAL ? "var(--carmin)" : "";
    }
    btn.addEventListener("click", function () {
      if (id) { clearInterval(id); id = null; btn.textContent = "Seguir"; return; }
      btn.textContent = "Pausar"; id = setInterval(function () { seg++; pinta(); }, 1000);
    });
    $("#reloj-reset").addEventListener("click", function () { clearInterval(id); id = null; seg = 0; btn.textContent = "Iniciar"; pinta(); });
    tramos.forEach(function (t) { t.addEventListener("click", function () { seg = +t.dataset.ini; pinta(); }); });
    document.addEventListener("vista", function (e) { if (e.detail !== "guion" && id) { clearInterval(id); id = null; btn.textContent = "Seguir"; } });
    pinta();
  })();

  /* ------------------------------------------------------------------ cierre */
  $("#registro-copiar").addEventListener("click", function () { copiar($("#registro").textContent, this); });

  /* ------------------------------------------------------------------ arranque */
  progreso(); desdeHash();
})();

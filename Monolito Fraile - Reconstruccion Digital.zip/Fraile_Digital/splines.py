"""Núcleo matemático de la app: spline cúbico natural paramétrico, en Python puro.

No usa NumPy ni SciPy: solo la biblioteca estándar. El sistema tridiagonal se resuelve
con el algoritmo de Thomas. Es la misma construcción que `codigo/spline_propio.py`.
"""
from __future__ import annotations

import csv
import math
from pathlib import Path

ALTO_IMAGEN = 1516  # px. El CSV guarda y = ALTO - y_imagen (eje y hacia arriba).


def leer_puntos(ruta: Path) -> list[tuple[float, float]]:
    with open(ruta, newline="", encoding="utf-8") as f:
        filas = list(csv.reader(f))
    return [(float(x), float(y)) for x, y in filas[1:] if x.strip()]


def parametro_centripeto(puntos):
    """t_0 = 0 y t_{i+1} = t_i + sqrt(|P_{i+1} - P_i|)  (parametrización centrípeta)."""
    t = [0.0]
    for (x0, y0), (x1, y1) in zip(puntos, puntos[1:]):
        t.append(t[-1] + math.sqrt(math.hypot(x1 - x0, y1 - y0)))
    return t


def _resolver_c(t, y):
    """Resuelve el sistema tridiagonal del spline natural: devuelve los c_i (i = 0..n)."""
    n = len(t) - 1
    h = [t[i + 1] - t[i] for i in range(n)]
    if n < 2:
        return [0.0] * (n + 1)
    # Filas 1..n-1: h[i-1]*c[i-1] + 2(h[i-1]+h[i])*c[i] + h[i]*c[i+1] = r[i]
    a = [h[i - 1] for i in range(1, n)]
    b = [2.0 * (h[i - 1] + h[i]) for i in range(1, n)]
    c_ = [h[i] for i in range(1, n)]
    r = [3.0 * ((y[i + 1] - y[i]) / h[i] - (y[i] - y[i - 1]) / h[i - 1]) for i in range(1, n)]
    m = n - 1
    for i in range(1, m):                       # eliminación hacia adelante
        w = a[i] / b[i - 1]
        b[i] -= w * c_[i - 1]
        r[i] -= w * r[i - 1]
    x = [0.0] * m
    x[-1] = r[-1] / b[-1]
    for i in range(m - 2, -1, -1):              # sustitución hacia atrás
        x[i] = (r[i] - c_[i] * x[i + 1]) / b[i]
    return [0.0] + x + [0.0]                    # natural: c_0 = c_n = 0


def coeficientes(t, y):
    """Coeficientes (a, b, c, d) de cada tramo: S_i(s) = a + b u + c u² + d u³, u = s - t_i."""
    n = len(t) - 1
    h = [t[i + 1] - t[i] for i in range(n)]
    c = _resolver_c(t, y)
    a = y[:-1]
    b = [(y[i + 1] - y[i]) / h[i] - h[i] * (2 * c[i] + c[i + 1]) / 3 for i in range(n)]
    d = [(c[i + 1] - c[i]) / (3 * h[i]) for i in range(n)]
    return a, b, c[:-1], d


class SplineParametrico:
    def __init__(self, puntos):
        self.puntos = [tuple(p) for p in puntos]
        self.t = parametro_centripeto(self.puntos)
        xs = [p[0] for p in self.puntos]
        ys = [p[1] for p in self.puntos]
        self.cx = coeficientes(self.t, xs)
        self.cy = coeficientes(self.t, ys)
        self.n = len(self.puntos) - 1  # número de tramos

    def tramo(self, s):
        for i in range(self.n):
            if s < self.t[i + 1]:
                return i
        return self.n - 1

    def _poli(self, coefs, i, u, orden):
        a, b, c, d = (coefs[0][i], coefs[1][i], coefs[2][i], coefs[3][i])
        if orden == 0:
            return a + b * u + c * u * u + d * u ** 3
        if orden == 1:
            return b + 2 * c * u + 3 * d * u * u
        return 2 * c + 6 * d * u

    def evalua(self, s, orden=0, i=None):
        i = self.tramo(s) if i is None else i
        u = s - self.t[i]
        return (self._poli(self.cx, i, u, orden), self._poli(self.cy, i, u, orden))

    def muestras(self, por_tramo=40):
        """Lista de polilíneas: una por tramo, con `por_tramo`+1 puntos (incluye extremos)."""
        salida = []
        for i in range(self.n):
            h = self.t[i + 1] - self.t[i]
            pts = [self.evalua(self.t[i] + h * k / por_tramo, 0, i) for k in range(por_tramo + 1)]
            salida.append(pts)
        return salida

    def continuidad(self):
        """Salto máximo de posición, tangente y curvatura entre tramos vecinos (nodos interiores)."""
        e = [0.0, 0.0, 0.0]
        detalle = []
        for i in range(1, self.n):
            fila = []
            for orden in (0, 1, 2):
                izq = self.evalua(self.t[i], orden, i - 1)
                der = self.evalua(self.t[i], orden, i)
                err = math.hypot(izq[0] - der[0], izq[1] - der[1])
                e[orden] = max(e[orden], err)
                fila.append(err)
            detalle.append(fila)
        return {"C0": e[0], "C1": e[1], "C2": e[2], "nodos": detalle}

    def pasa_por_los_puntos(self):
        """Máxima distancia entre el spline evaluado en cada t_i y el punto de control P_i."""
        peor = 0.0
        for i, p in enumerate(self.puntos):
            s = self.t[i]
            q = self.evalua(s, 0, min(i, self.n - 1))
            peor = max(peor, math.hypot(q[0] - p[0], q[1] - p[1]))
        # último punto, evaluado con el último tramo
        q = self.evalua(self.t[-1], 0, self.n - 1)
        peor = max(peor, math.hypot(q[0] - self.puntos[-1][0], q[1] - self.puntos[-1][1]))
        return peor

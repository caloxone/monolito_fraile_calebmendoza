@echo off
chcp 65001 >nul
title Fraile Digital
cd /d "%~dp0"
where python >nul 2>nul || (echo No se encontro Python. Instalalo desde https://www.python.org/downloads/ y marca "Add Python to PATH". & pause & exit /b 1)
if not exist ".venv" (
  echo Preparando la app por primera vez...
  python -m venv .venv
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip >nul
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
echo.
echo Abre http://127.0.0.1:5000 en tu navegador. Para cerrar la app presiona Ctrl+C.
start "" http://127.0.0.1:5000
python app.py
pause
